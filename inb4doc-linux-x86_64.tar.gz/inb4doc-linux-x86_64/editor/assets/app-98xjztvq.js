import {
  getLineBefore
} from "./app-9metdmjj.js";

// node_modules/prism-code-editor/dist/shared-c_zHT_t0.js
var clikeIndent = /[([{][^)\]}]*$|^[^.]*\b(?:case .+?|default):\s*$/;
var isBracketPair = /\[]|\(\)|{}/;
var xmlOpeningTag = /<(?![\d?!#@])([^\s/=>$<%]+)(?:\s(?:\s*[^\s/"'=>]+(?:\s*=\s*(?!\s)(?:"[^"]*"|'[^']*'|[^\s"'=>]+(?=[\s>]))?|(?=[\s/>])))+)?\s*>[ 	]*$/;
var xmlClosingTag = /^<\/(?!\d)[^\s/=>$<%]+\s*>/;
var openBracket = /[([{][^)\]}]*$/;
var testBracketPair = ([start, end], value) => {
  return isBracketPair.test(value[start - 1] + value[end]);
};
var clikeComment = {
  line: "//",
  block: ["/*", "*/"]
};
var isOpen = (match, voidTags2) => !!match && !voidTags2?.test(match[1]);
var htmlAutoIndent = (tagPattern, voidTags2) => [([start], value) => isOpen(value.slice(0, start).match(tagPattern), voidTags2) || openBracket.test(getLineBefore(value, start)), (selection, value) => testBracketPair(selection, value) || isOpen(value.slice(0, selection[0]).match(tagPattern), voidTags2) && xmlClosingTag.test(value.slice(selection[1]))];
var markupComment = { block: ["<!--", "-->"] };
var markupLanguage = (comment = markupComment, tagPattern = xmlOpeningTag, voidTags2) => ({
  comments: comment,
  autoIndent: htmlAutoIndent(tagPattern, voidTags2),
  autoCloseTags: ([start, end], value, editor) => {
    return autoCloseTags(editor, start, end, value, tagPattern, voidTags2);
  }
});
var autoCloseTags = (editor, start, end, value, tagPattern, voidTags2) => {
  if (start == end) {
    let match = tagPattern.exec(value.slice(0, start) + ">");
    let tagMatcher = editor.extensions.matchTags;
    if (match && (match = match[1] || "", !voidTags2?.test(match))) {
      if (tagMatcher) {
        let { pairs, tags } = tagMatcher;
        for (let i = tags.length;i; ) {
          let tag = tags[--i];
          if (tag[1] >= start && tag[4] && tag[5] && tag[3] == match && pairs[i] == null)
            return;
        }
      }
      return `</${match}>`;
    }
  }
};

export { clikeIndent, xmlOpeningTag, testBracketPair, clikeComment, markupComment, markupLanguage, autoCloseTags };
