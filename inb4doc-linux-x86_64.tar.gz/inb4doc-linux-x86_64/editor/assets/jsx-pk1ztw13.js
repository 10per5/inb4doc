import {
  autoCloseTags,
  clikeComment,
  clikeIndent,
  testBracketPair
} from "./app-26vfkf71.js";
import {
  getClosestToken,
  getLineBefore,
  languageMap
} from "./app-pqbsecvn.js";
import {
  braces,
  space
} from "./app-nfc0k988.js";
import {
  re
} from "./app-v8v73v6d.js";
import"./app-086jmyb9.js";
import"./app-ky8th4fh.js";
import"./app-0mckv39t.js";
import"./app-2vd5xdaq.js";

// node_modules/prism-code-editor/dist/languages/jsx.js
var openingTag = re(`(?:^|[^\\w$])<(?:(?!\\d)([^\\s%=<>/]+)(?:(?:<0>|<0>*<(?:[^<>=]|=[^<]|=?<(?:[^<>]|<[^<>]*>)*>)*>)(?:<0>*(?:[^\\s"'{=<>/*]+(?:<0>*=<0>*(?!\\s)(?:"[^"]*"|'[^']*'|<1>)?|(?=[\\s/>]))|<1>))*)?<0>*)?>[ 	]*$`, [space, braces]);
var closingTag = /^<\/(?!\d)[^\s%=<>/]*\s*>/;
var inJsxContext = ({ tags, pairs }, { brackets, pairs: bracketPairs }, position) => {
  for (let i = tags.length, tag, min = 0;tag = tags[--i]; )
    if (tag[2] > position && tag[1] < position)
      min = tag[1];
    else if (!tag[4] && tag[5] && tag[1] >= min && tag[2] <= position && !(tags[pairs[i]]?.[1] < position)) {
      for (let i2 = brackets.length, bracket;bracket = brackets[--i2]; )
        if (bracket[1] >= tag[2] && bracket[1] < position && bracket[4] == "{" && !(brackets[bracketPairs[i2]]?.[1] < position))
          return;
      return true;
    }
};
var jsxComment = { block: ["{/*", "*/}"] };
languageMap.jsx = languageMap.tsx = {
  comments: clikeComment,
  getComments(editor, position) {
    const { matchBrackets, matchTags } = editor.extensions;
    return (matchBrackets && matchTags ? inJsxContext(matchTags, matchBrackets, position) : getClosestToken(editor, ".plain-text", 0, 0, position)) ? jsxComment : clikeComment;
  },
  autoIndent: [([start], value) => openingTag.test(value.slice(0, start)) || clikeIndent.test(getLineBefore(value, start)), (selection, value) => testBracketPair(selection, value) || openingTag.test(value.slice(0, selection[0])) && closingTag.test(value.slice(selection[1]))],
  autoCloseTags: ([start, end], value, editor) => {
    return autoCloseTags(editor, start, end, value, openingTag);
  }
};
