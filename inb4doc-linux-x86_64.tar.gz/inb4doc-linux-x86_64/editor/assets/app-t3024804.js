import {
  addJsxTag
} from "./app-nfc0k988.js";
import {
  languages
} from "./app-0mckv39t.js";

// node_modules/prism-code-editor/dist/prism/languages/jsx.js
addJsxTag(languages.js, "jsx");
