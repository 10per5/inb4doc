import {
  createProviderByType
} from "./app-ezg4xrk5.js";
import"./app-2vd5xdaq.js";
export {
  createProviderByType
};
