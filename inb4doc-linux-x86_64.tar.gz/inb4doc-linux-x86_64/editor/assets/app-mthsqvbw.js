// src/stores/connection-store.ts
var STORAGE_KEY = "inb4doc-connection";
var DEFAULTS = {
  host: "localhost",
  port: 5000
};
function load() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw)
      return { ...DEFAULTS, ...JSON.parse(raw) };
  } catch {}
  return null;
}
function save(config) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
  } catch {}
}

class ConnectionStore {
  config = load();
  _remoteAvailable = false;
  getHost() {
    return this.config?.host ?? DEFAULTS.host;
  }
  getPort() {
    return this.config?.port ?? DEFAULTS.port;
  }
  getConfig() {
    return this.config ? { ...this.config } : { ...DEFAULTS };
  }
  setConfig(host, port) {
    this.config = { host, port };
    save(this.config);
    this._remoteAvailable = false;
  }
  isCustom() {
    return this.config !== null;
  }
  getBaseUrl() {
    if (!this.config)
      return "";
    return `http://${this.config.host}:${this.config.port}`;
  }
  get remoteAvailable() {
    return this._remoteAvailable;
  }
  set remoteAvailable(v) {
    this._remoteAvailable = v;
  }
  async probe(timeout = 3000) {
    const controller = new AbortController;
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const res = await fetch(this.getBaseUrl() + "/api/tree", {
        method: "HEAD",
        signal: controller.signal
      });
      clearTimeout(timer);
      this._remoteAvailable = res.ok || res.status === 200;
    } catch {
      clearTimeout(timer);
      this._remoteAvailable = false;
    }
    return this._remoteAvailable;
  }
}
var connectionStore = new ConnectionStore;

// src/providers/remote-provider.ts
class RemoteProvider {
  name = "remote";
  url(path) {
    return `${connectionStore.getBaseUrl()}${path}`;
  }
  async isAvailable() {
    return connectionStore.probe();
  }
  async getTree() {
    const res = await fetch(this.url("/api/tree"));
    if (!res.ok)
      return {};
    return res.json();
  }
  async readFile(path) {
    const res = await fetch(this.url(`/content/${path}.md`));
    if (!res.ok)
      return null;
    return res.text();
  }
  async writeFile(path, content) {
    await fetch(this.url(`/content/${path}.md`), {
      method: "PUT",
      headers: { "Content-Type": "text/markdown" },
      body: content
    });
  }
  async deleteFile(path) {
    await fetch(this.url(`/content/${path}.md`), { method: "DELETE" });
  }
  async moveFile(from, to) {
    const res = await fetch(this.url("/api/move"), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ from: `${from}.md`, to: `${to}.md` })
    });
    if (!res.ok)
      throw new Error(`Move failed: ${res.status}`);
  }
  async search(query) {
    const res = await fetch(this.url("/api/search"), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query })
    });
    if (!res.ok)
      return [];
    const data = await res.json();
    return data.results ?? [];
  }
  async getServerTime(path) {
    const res = await fetch(this.url(`/content/${path}.md`), { method: "HEAD" });
    if (!res.ok)
      return null;
    const lastModified = res.headers.get("Last-Modified");
    if (!lastModified)
      return null;
    return new Date(lastModified).getTime();
  }
  async uploadImage(file, dir) {
    const form = new FormData;
    form.append("file", file);
    form.append("dir", dir);
    const resp = await fetch(this.url("/api/upload"), { method: "POST", body: form });
    if (!resp.ok)
      throw new Error(`Upload failed: ${resp.statusText}`);
    const result = await resp.json();
    return result.url;
  }
  async listImages(dir, refs) {
    const params = new URLSearchParams({ dir });
    if (refs)
      params.set("refs", "true");
    const resp = await fetch(this.url(`/api/images?${params}`));
    if (!resp.ok)
      throw new Error(`Failed to list images: ${resp.statusText}`);
    const data = await resp.json();
    return data.images.map((img) => ({
      name: img.name,
      url: img.url,
      storageUrl: `image/${img.name}`,
      usedIn: img.usedIn || []
    }));
  }
  resolveImageUrl(url) {
    return;
  }
  async deleteImage(name, dir) {
    const resp = await fetch(this.url(`/api/images/${encodeURIComponent(name)}?dir=${encodeURIComponent(dir)}`), {
      method: "DELETE"
    });
    if (!resp.ok)
      throw new Error(`Failed to delete image: ${resp.statusText}`);
  }
}

// src/utils/content-search.ts
function contentMatches(content, query) {
  return content.toLowerCase().includes(query.toLowerCase().trim());
}
function extractTableCells(table, query) {
  const q = query.toLowerCase();
  const rows = table.split(`
`).filter((r) => r.trim().startsWith("|") && !r.includes("---"));
  const results = [];
  for (let ri = 0;ri < rows.length; ri++) {
    const cells = rows[ri].split("|").slice(1, -1).map((c) => c.trim());
    for (let ci = 0;ci < cells.length; ci++) {
      if (cells[ci].toLowerCase().includes(q)) {
        results.push(cells[ci]);
      }
    }
  }
  return results;
}
function extractSnippets(content, query, maxSnippets = 3) {
  const q = query.toLowerCase().trim();
  if (!q)
    return [];
  const paragraphs = content.split(/\n\s*\n/);
  const snippets = [];
  for (const para of paragraphs) {
    if (para.toLowerCase().includes(q)) {
      if (para.trim().startsWith("|")) {
        const cells = extractTableCells(para, q);
        snippets.push(...cells);
      } else {
        snippets.push(para.trim());
      }
      if (snippets.length >= maxSnippets)
        break;
    }
  }
  return snippets;
}

// src/utils/sanitize.ts
var ALLOWED_IMG_EXTS = ["png", "jpg", "jpeg", "gif", "svg", "webp", "bmp", "ico"];
function sanitizeImageName(name) {
  const dot = name.lastIndexOf(".");
  const rawExt = dot >= 0 ? name.slice(dot).toLowerCase() : "";
  const extBody = rawExt.replace(".", "");
  const safeExt = ALLOWED_IMG_EXTS.includes(extBody) ? rawExt : ".png";
  const base = (dot >= 0 ? name.slice(0, dot) : name).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 40);
  const suffix = Math.random().toString(36).slice(2, 8);
  return `${base || "image"}-${suffix}${safeExt}`;
}

// src/providers/fs-provider.ts
class FileSystemProvider {
  name = "fs";
  dirHandle = null;
  imageUrlCache = new Map;
  currentDir = "";
  async isAvailable() {
    return typeof window.showDirectoryPicker === "function";
  }
  async init() {
    if (this.dirHandle)
      return;
    this.dirHandle = await window.showDirectoryPicker();
  }
  async getTree() {
    if (!this.dirHandle)
      await this.init();
    const result = {};
    await this.buildTree(this.dirHandle, result);
    return result;
  }
  async buildTree(dir, out) {
    for await (const entry of dir.values()) {
      if (entry.name.startsWith("."))
        continue;
      if (entry.kind === "directory") {
        const children = {};
        await this.buildTree(entry, children);
        if (Object.keys(children).length > 0) {
          out[entry.name] = children;
        }
      } else if (entry.name.endsWith(".md")) {
        const file = await entry.getFile();
        const text = await file.text();
        const match = text.match(/^---\n([\s\S]*?)\n---/);
        if (match) {
          const weightMatch = match[1].match(/^weight:\s*(\d+)/m);
          if (weightMatch) {
            out[entry.name] = { weight: parseInt(weightMatch[1], 10) };
            continue;
          }
        }
        out[entry.name] = null;
      }
    }
  }
  async readFile(path) {
    if (!this.dirHandle)
      await this.init();
    const parts = path.split("/").filter(Boolean);
    let current = this.dirHandle;
    for (let i = 0;i < parts.length - 1; i++) {
      current = await current.getDirectoryHandle(parts[i]);
    }
    const fileName = parts[parts.length - 1] + ".md";
    try {
      const fileHandle = await current.getFileHandle(fileName);
      const file = await fileHandle.getFile();
      return await file.text();
    } catch {
      return null;
    }
  }
  async writeFile(path, content) {
    if (!this.dirHandle)
      await this.init();
    const parts = path.split("/").filter(Boolean);
    let current = this.dirHandle;
    for (let i = 0;i < parts.length - 1; i++) {
      current = await current.getDirectoryHandle(parts[i], { create: true });
    }
    const fileName = parts[parts.length - 1] + ".md";
    const fileHandle = await current.getFileHandle(fileName, { create: true });
    const writable = await fileHandle.createWritable();
    await writable.write(content);
    await writable.close();
  }
  async deleteFile(path) {
    if (!this.dirHandle)
      await this.init();
    const parts = path.split("/").filter(Boolean);
    const dir = parts.slice(0, -1).join("/");
    let current = this.dirHandle;
    for (let i = 0;i < parts.length - 1; i++) {
      current = await current.getDirectoryHandle(parts[i]);
    }
    const fileName = parts[parts.length - 1] + ".md";
    await current.removeEntry(fileName);
    await this.cleanupEmptyParents(current, parts.slice(0, -1));
    await this.removeOrphanedImages(dir);
  }
  async cleanupEmptyParents(dir, parts) {
    if (parts.length === 0)
      return;
    for await (const _ of dir.values()) {
      return;
    }
    const parentName = parts.pop();
    if (!parentName)
      return;
    const parent = await this.getParentDir(parts);
    if (parent) {
      try {
        await parent.removeEntry(parentName);
        await this.cleanupEmptyParents(parent, parts);
      } catch {}
    }
  }
  async getParentDir(parts) {
    if (!this.dirHandle)
      return null;
    if (parts.length === 0)
      return this.dirHandle;
    let current = this.dirHandle;
    for (const part of parts) {
      try {
        current = await current.getDirectoryHandle(part);
      } catch {
        return null;
      }
    }
    return current;
  }
  async moveFile(from, to) {
    const content = await this.readFile(from);
    if (content === null)
      throw new Error("Source not found");
    await this.writeFile(to, content);
    await this.deleteFile(from);
  }
  async search(query) {
    if (!this.dirHandle)
      await this.init();
    return this.searchInDir(this.dirHandle, "", query);
  }
  async searchInDir(dir, prefix, query) {
    const results = [];
    for await (const entry of dir.values()) {
      if (entry.name.startsWith("."))
        continue;
      if (entry.kind === "directory") {
        if (entry.name === "image")
          continue;
        const sub = await this.searchInDir(entry, prefix ? `${prefix}/${entry.name}` : entry.name, query);
        results.push(...sub);
      } else if (entry.name.endsWith(".md")) {
        const file = await entry.getFile();
        const body = await file.text();
        if (contentMatches(body, query)) {
          const full = prefix ? `${prefix}/${entry.name}` : entry.name;
          results.push({
            path: full.replace(/\.md$/, ""),
            snippets: extractSnippets(body, query)
          });
        }
      }
    }
    return results;
  }
  async getServerTime(path) {
    if (!this.dirHandle)
      await this.init();
    const parts = path.split("/").filter(Boolean);
    let current = this.dirHandle;
    for (let i = 0;i < parts.length - 1; i++) {
      current = await current.getDirectoryHandle(parts[i]);
    }
    const fileName = parts[parts.length - 1] + ".md";
    try {
      const fileHandle = await current.getFileHandle(fileName);
      const file = await fileHandle.getFile();
      return file.lastModified;
    } catch {
      return null;
    }
  }
  async ensureImageDir(dir) {
    if (!this.dirHandle)
      await this.init();
    const parts = dir.split("/").filter(Boolean);
    let current = this.dirHandle;
    for (const part of parts) {
      current = await current.getDirectoryHandle(part, { create: true });
    }
    return await current.getDirectoryHandle("image", { create: true });
  }
  async uploadImage(file, dir) {
    const name = sanitizeImageName(file.name);
    const relPath = `image/${name}`;
    const imageDir = await this.ensureImageDir(dir);
    const fileHandle = await imageDir.getFileHandle(name, { create: true });
    const writable = await fileHandle.createWritable();
    await writable.write(file);
    await writable.close();
    const blobUrl = URL.createObjectURL(file);
    this.imageUrlCache.set(`${dir}/${relPath}`, blobUrl);
    return relPath;
  }
  resolveImageUrl(url) {
    const exact = this.imageUrlCache.get(url);
    if (exact)
      return exact;
    if (this.currentDir) {
      return this.imageUrlCache.get(`${this.currentDir}/${url}`);
    }
    return;
  }
  async listImages(dir, refs) {
    this.currentDir = dir;
    let imageDir;
    try {
      imageDir = await this.ensureImageDir(dir);
    } catch {
      return [];
    }
    const entries = [];
    const imageNames = [];
    for await (const entry of imageDir.values()) {
      if (entry.kind !== "file")
        continue;
      const name = entry.name;
      const ext = name.includes(".") ? name.split(".").pop().toLowerCase() : "";
      if (!["png", "jpg", "jpeg", "gif", "svg", "webp", "bmp", "ico"].includes(ext))
        continue;
      imageNames.push(name);
    }
    imageNames.sort();
    const scanDir = dir ? dir : "";
    const mdFiles = refs ? await this.collectMdFiles(scanDir) : new Map;
    for (const name of imageNames) {
      const storageUrl = `image/${name}`;
      const cacheKey = `${dir}/${storageUrl}`;
      let displayUrl = this.imageUrlCache.get(cacheKey);
      if (!displayUrl) {
        displayUrl = this.imageUrlCache.get(storageUrl);
      }
      if (!displayUrl) {
        try {
          const imageDir2 = await this.ensureImageDir(dir);
          const fileHandle = await imageDir2.getFileHandle(name);
          const file = await fileHandle.getFile();
          displayUrl = URL.createObjectURL(file);
          this.imageUrlCache.set(cacheKey, displayUrl);
        } catch {
          displayUrl = "";
        }
      }
      const usedIn = refs ? this.findRefsInFiles(name, mdFiles) : [];
      entries.push({ name, url: displayUrl, storageUrl, usedIn });
    }
    return entries;
  }
  async collectMdFiles(dir) {
    const result = new Map;
    if (!this.dirHandle)
      await this.init();
    async function walk(handle2, prefix, skipImage, out) {
      for await (const entry of handle2.values()) {
        if (entry.name.startsWith("."))
          continue;
        if (entry.kind === "directory") {
          if (skipImage && entry.name === "image")
            continue;
          await walk(entry, prefix ? `${prefix}/${entry.name}` : entry.name, skipImage, out);
        } else if (entry.name.endsWith(".md")) {
          const file = await entry.getFile();
          const text = await file.text();
          const rel = prefix ? `${prefix}/${entry.name}` : entry.name;
          out.set(rel, text);
        }
      }
    }
    let handle = this.dirHandle;
    if (dir) {
      const parts = dir.split("/").filter(Boolean);
      for (const part of parts) {
        handle = await handle.getDirectoryHandle(part);
      }
    }
    await walk(handle, dir, true, result);
    return result;
  }
  findRefsInFiles(imageName, files) {
    const refs = [];
    for (const [relPath, content] of files) {
      if (content.includes(imageName)) {
        refs.push(relPath);
      }
    }
    return refs;
  }
  async deleteImage(name, dir) {
    try {
      const imageDir = await this.ensureImageDir(dir);
      await imageDir.removeEntry(name);
    } catch {}
  }
  async removeOrphanedImages(dir) {
    let imageDir;
    try {
      imageDir = await this.ensureImageDir(dir);
    } catch {
      return;
    }
    const mdFiles = await this.collectMdFiles(dir);
    for await (const entry of imageDir.values()) {
      if (entry.kind !== "file")
        continue;
      const refs = this.findRefsInFiles(entry.name, mdFiles);
      if (refs.length === 0) {
        try {
          await imageDir.removeEntry(entry.name);
        } catch {}
      }
    }
  }
}

// src/providers/local-storage-provider.ts
var STORAGE_PREFIX = "inb4doc:";
var IMAGE_PREFIX = "inb4doc:image:";

class LocalStorageProvider {
  name = "localStorage";
  async isAvailable() {
    return true;
  }
  async getTree() {
    const result = {};
    const mdKeys = this.getAllMdKeys();
    for (const key of mdKeys) {
      const relPath = key.slice(STORAGE_PREFIX.length);
      const parts = relPath.split("/");
      let current = result;
      for (let i = 0;i < parts.length; i++) {
        const isLeaf = i === parts.length - 1;
        if (isLeaf) {
          const content = localStorage.getItem(key);
          if (content) {
            const match = content.match(/^---\n([\s\S]*?)\n---/);
            if (match) {
              const weightMatch = match[1].match(/^weight:\s*(\d+)/m);
              if (weightMatch) {
                current[parts[i]] = { weight: parseInt(weightMatch[1], 10) };
                continue;
              }
            }
          }
          current[parts[i]] = null;
        } else {
          if (!current[parts[i]] || typeof current[parts[i]] !== "object" || current[parts[i]] === null) {
            current[parts[i]] = {};
          }
          current = current[parts[i]];
        }
      }
    }
    return result;
  }
  getAllMdKeys() {
    const keys = [];
    for (let i = 0;i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith(STORAGE_PREFIX) && key.endsWith(".md")) {
        keys.push(key);
      }
    }
    return keys;
  }
  async readFile(path) {
    return localStorage.getItem(STORAGE_PREFIX + path + ".md");
  }
  async writeFile(path, content) {
    localStorage.setItem(STORAGE_PREFIX + path + ".md", content);
  }
  async deleteFile(path) {
    localStorage.removeItem(STORAGE_PREFIX + path + ".md");
    this.removeOrphanedImages();
  }
  async moveFile(from, to) {
    const content = await this.readFile(from);
    if (content === null)
      throw new Error("Source not found");
    await this.writeFile(to, content);
    await this.deleteFile(from);
  }
  async getServerTime(_path) {
    return null;
  }
  async search(query) {
    const results = [];
    for (let i = 0;i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (!key || !key.startsWith(STORAGE_PREFIX) || !key.endsWith(".md"))
        continue;
      const body = localStorage.getItem(key);
      if (body && contentMatches(body, query)) {
        results.push({
          path: key.slice(STORAGE_PREFIX.length).replace(/\.md$/, ""),
          snippets: extractSnippets(body, query)
        });
      }
    }
    return results;
  }
  async fileToBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader;
      reader.onload = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }
  async uploadImage(file, _dir) {
    const ext = file.name.includes(".") ? file.name.split(".").pop() : "png";
    const name = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
    const base64 = await this.fileToBase64(file);
    localStorage.setItem(IMAGE_PREFIX + name, base64);
    return `inb4doc-image:${name}`;
  }
  async listImages(_dir, refs) {
    const entries = [];
    for (let i = 0;i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith(IMAGE_PREFIX)) {
        const name = key.slice(IMAGE_PREFIX.length);
        const base64 = localStorage.getItem(key);
        const usedIn = refs ? this.findRefs(name) : [];
        entries.push({ name, url: base64, storageUrl: `inb4doc-image:${name}`, usedIn });
      }
    }
    return entries;
  }
  resolveImageUrl(url) {
    if (url.startsWith("inb4doc-image:")) {
      const name = url.slice("inb4doc-image:".length);
      return localStorage.getItem(IMAGE_PREFIX + name) || undefined;
    }
    return;
  }
  findRefs(imageName) {
    const refs = [];
    for (let i = 0;i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith(STORAGE_PREFIX) && key.endsWith(".md")) {
        const content = localStorage.getItem(key);
        if (content && content.includes(`inb4doc-image:${imageName}`)) {
          refs.push(key.slice(STORAGE_PREFIX.length));
        }
      }
    }
    return refs;
  }
  async deleteImage(name, _dir) {
    localStorage.removeItem(IMAGE_PREFIX + name);
  }
  removeOrphanedImages() {
    const imageKeys = [];
    for (let i = 0;i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith(IMAGE_PREFIX)) {
        imageKeys.push(key);
      }
    }
    for (const key of imageKeys) {
      const name = key.slice(IMAGE_PREFIX.length);
      const refs = this.findRefs(name);
      if (refs.length === 0) {
        localStorage.removeItem(key);
      }
    }
  }
}

// src/providers/index.ts
async function createProvider() {
  const controller = new AbortController;
  const id = setTimeout(() => controller.abort(), 500);
  try {
    const res = await fetch("/api/tree", {
      method: "HEAD",
      signal: controller.signal
    });
    clearTimeout(id);
    console.log("[content] probe /api/tree ->", res.status);
    if (res.ok || res.status === 200) {
      console.log("[content] using RemoteProvider");
      return new RemoteProvider;
    }
  } catch (e) {
    clearTimeout(id);
    console.log("[content] probe failed:", e);
  }
  const fsAPI = window.showDirectoryPicker;
  console.log("[content] showDirectoryPicker:", typeof fsAPI);
  if (fsAPI) {
    console.log("[content] using FileSystemProvider");
    return new FileSystemProvider;
  }
  console.log("[content] using LocalStorageProvider (Firefox fallback)");
  return new LocalStorageProvider;
}
function getProviderTypeName(type) {
  switch (type) {
    case "remote":
      return "remote";
    case "filesystem":
      return "fs";
    case "localStorage":
      return "localStorage";
  }
}
async function getAvailableProviders() {
  const providers = [];
  let remoteAvailable = false;
  try {
    const controller = new AbortController;
    const id = setTimeout(() => controller.abort(), 500);
    const res = await fetch("/api/tree", {
      method: "HEAD",
      signal: controller.signal
    });
    clearTimeout(id);
    remoteAvailable = res.ok || res.status === 200;
  } catch {}
  providers.push({
    type: "remote",
    description: "Files served from a backend server via HTTP API",
    available: remoteAvailable,
    reason: remoteAvailable ? undefined : "No content server detected"
  });
  const hasFs = typeof window.showDirectoryPicker === "function";
  providers.push({
    type: "filesystem",
    description: "Access local markdown files via the File System Access API (Chrome/Edge)",
    available: hasFs,
    reason: hasFs ? undefined : "Not supported in this browser (use Chrome or Edge)"
  });
  providers.push({
    type: "localStorage",
    description: "Store files in browser local storage — persists across sessions",
    available: true
  });
  return providers;
}
function createProviderByType(type) {
  switch (type) {
    case "remote":
      return new RemoteProvider;
    case "filesystem":
      return new FileSystemProvider;
    case "localStorage":
      return new LocalStorageProvider;
  }
}

export { connectionStore, extractSnippets, LocalStorageProvider, createProvider, getProviderTypeName, getAvailableProviders, createProviderByType };
