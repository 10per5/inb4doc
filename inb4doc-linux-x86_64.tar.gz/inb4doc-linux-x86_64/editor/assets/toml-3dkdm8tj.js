import {
  re
} from "./app-v8v73v6d.js";
import {
  boolean
} from "./app-ky8th4fh.js";
import {
  languages
} from "./app-db5x50nb.js";

// node_modules/prism-code-editor/dist/prism/languages/toml.js
var insertKey = (pattern) => re(pattern, [`(?:[\\w-]+|'[^
']*'|"(?:\\\\.|[^\\\\"
])*")`], "mg");
languages.toml = {
  comment: /#.*/g,
  table: {
    pattern: insertKey("(^[ \t]*\\[\\s*(?:\\[\\s*)?)<0>(?:\\s*\\.\\s*<0>)*(?=\\s*\\])"),
    lookbehind: true,
    alias: "class-name"
  },
  key: {
    pattern: insertKey("(^[ \t]*|[{,]\\s*)<0>(?:\\s*\\.\\s*<0>)*(?=\\s*=)"),
    lookbehind: true,
    alias: "property"
  },
  string: /"""(?:\\[^]|[^\\])*?"""|'''[^]*?'''|'[^\n']*'|"(?:\\.|[^\\\n"])*"/g,
  date: {
    pattern: /\b(?:\d{4}-\d\d-\d\d(?:[t\s]\d\d:\d\d:\d\d(?:\.\d+)?(?:z|[+-]\d\d:\d\d)?)?|\d\d:\d\d:\d\d(?:\.\d+)?)\b/i,
    alias: "number"
  },
  number: /(?:\b0(?:x[a-zA-Z\d]+(?:_[a-zA-Z\d]+)*|o[0-7]+(?:_[0-7]+)*|b[10]+(?:_[10]+)*))\b|[+-]?\b\d+(?:_\d+)*(?:\.\d+(?:_\d+)*)?(?:[eE][+-]?\d+(?:_\d+)*)?\b|[+-]?\b(?:inf|nan)\b/,
  boolean,
  punctuation: /[[\]{}.,=]/
};
