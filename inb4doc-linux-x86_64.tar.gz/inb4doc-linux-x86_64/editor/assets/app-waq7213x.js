var f=/\/\/.*|\/\*[^]*?(?:\*\/|$)/g,h=/(["'])(?:\\[^]|(?!\1)[^\\\n])*\1/g,q=/\b0x[a-f\d]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,v=/[()[\]{}.,:;]/,w=/\b(?:false|true)\b/,x={punctuation:/\./};
export{f as _,h as $,q as aa,v as ba,w as ca,x as da};
