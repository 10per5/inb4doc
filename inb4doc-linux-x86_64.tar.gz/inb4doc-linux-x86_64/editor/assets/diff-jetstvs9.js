import{U as q}from"./app-4wb7hyrj.js";var t=q.diff={coord:/^(?:\*{3}|-{3}|\+{3}|\d).*$|^@@.*@@$/m},k={"deleted-sign":"-","deleted-arrow":"<","inserted-sign":"\\+","inserted-arrow":">",unchanged:" ",diff:"!"};for(b in k)h=b.split("-")[0],t[b]={pattern:RegExp("(?:^"+k[b]+`.*
?)+`,"m"),alias:h!=b?h:b=="diff"?"bold":void 0,inside:{prefix:{pattern:RegExp("^"+k[b],"mg"),alias:h}}};var h,b;
