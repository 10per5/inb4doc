import {
  languages
} from "./app-db5x50nb.js";

// node_modules/prism-code-editor/dist/prism/languages/git.js
languages.git = {
  comment: /^#.*/m,
  deleted: /^[-–].*/m,
  inserted: /^\+.*/m,
  string: /(["'])(?:\\.|(?!\1)[^\\\n])*\1/,
  command: {
    pattern: /^.*\$ git .*/m,
    inside: { parameter: /\s--?\w+/ }
  },
  coord: /^@@.*@@$/m,
  "commit-sha1": /^commit \w{40}$/m
};
