var f=/\/\/.*|\/\*[^]*?(?:\*\/|$)/g,h=/(["'])(?:\\[^]|(?!\1)[^\\\n])*\1/g,q=/\b0x[a-f\d]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,v=/[()[\]{}.,:;]/,w=/\b(?:false|true)\b/,x={punctuation:/\./};
export{f as E,h as F,q as G,v as H,w as I,x as J};
