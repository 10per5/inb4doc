var f=/\/\/.*|\/\*[^]*?(?:\*\/|$)/g,h=/(["'])(?:\\[^]|(?!\1)[^\\\n])*\1/g,q=/\b0x[a-f\d]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,v=/[()[\]{}.,:;]/,w=/\b(?:false|true)\b/,x={punctuation:/\./};
export{f as H,h as I,q as J,v as K,w as L,x as M};
