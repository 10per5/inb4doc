import"./app-5zyhf0h5.js";
import {
  re,
  replace
} from "./app-v8v73v6d.js";
import {
  clone,
  insertBefore
} from "./app-bdyxzr9h.js";
import {
  languages,
  tokenize,
  tokenizeText,
  withoutTokenizer
} from "./app-db5x50nb.js";

// node_modules/prism-code-editor/dist/prism/languages/markdown.js
var inner = [`(?:\\\\.|[^\\\\
]|
(?!
))`];
var createInline = (pattern) => re(`((?:^|[^\\\\])(?:\\\\\\\\)*)(?:${pattern})`, inner, "g");
var tableCell = /(?:\\.|``(?:[^\n`]|`(?!`))+``|`[^\n`]+`|[^\\\n|`])+/;
var tableRow = replace(`\\|?<0>(?:\\|<0>)+\\|?(?:
|(?![\\s\\S]))`, [tableCell.source]);
var tableLine = `\\|?[ 	]*:?-{3,}:?[ 	]*(?:\\|[ 	]*:?-{3,}:?[ 	]*)+\\|?
`;
var markdown = languages.md = languages.markdown = clone(languages.html);
insertBefore(markdown, "prolog", {
  "front-matter-block": {
    pattern: /(^(?:\s*\n)?)---(?!.)[^]*?\n---(?!.)/g,
    lookbehind: true,
    inside: {
      punctuation: /^---|---$/,
      "front-matter": {
        pattern: /\S(?:[^]*\S)?/,
        alias: "language-yaml",
        inside: "yaml"
      }
    }
  },
  blockquote: {
    pattern: /^>(?:[ 	]*>)*/m,
    alias: "punctuation"
  },
  table: {
    pattern: RegExp("^" + tableRow + tableLine + "(?:" + tableRow + ")*", "m"),
    inside: {
      "table-header-row": {
        pattern: /^.+/,
        inside: {
          "table-header": {
            pattern: tableCell,
            alias: "important",
            inside: markdown
          },
          punctuation: /\|/
        }
      },
      "table-data-rows": {
        pattern: /(.+\n)[^]+/,
        lookbehind: true,
        inside: {
          "table-data": {
            pattern: tableCell,
            inside: markdown
          },
          punctuation: /\|/
        }
      },
      "table-line": {
        pattern: /.+/,
        inside: { punctuation: /\S+/ }
      }
    }
  },
  code: [{
    pattern: /(^[ 	]*\n)(?:    |	).+(?:\n(?:    |	).+)*/m,
    lookbehind: true,
    alias: "keyword"
  }, {
    pattern: /^(```+)[^`][^]*?^\1`*$/gm,
    inside: {
      punctuation: /^`+|`+$/,
      "code-language": /^.+/,
      "code-block": /(?!^)[^]+(?=\n)/,
      [tokenize](code, grammar) {
        var tokens = withoutTokenizer(code, grammar);
        var language;
        if (tokens[5]) {
          language = (/[a-z][\w-]*/i.exec(tokens[1].content.replace(/\b#/g, "sharp").replace(/\b\+\+/g, "pp")) || [""])[0].toLowerCase();
          tokens[3].alias = "language-" + language;
          if (grammar = languages[language])
            tokens[3].content = tokenizeText(tokens[3].content, grammar);
        }
        return tokens;
      }
    }
  }],
  title: [{
    pattern: /\S.*\n(?:==+|--+)(?=[ 	]*$)/m,
    alias: "important",
    inside: { punctuation: /=+$|-+$/ }
  }, {
    pattern: /(^\s*)#.+/m,
    lookbehind: true,
    alias: "important",
    inside: { punctuation: /^#+|#+$/ }
  }],
  hr: {
    pattern: /(^\s*)([*-])(?:[ 	]*\2){2,}(?=\s*$)/m,
    lookbehind: true,
    alias: "punctuation"
  },
  list: {
    pattern: /(^\s*)(?:[*+-]|\d+\.)(?=[ 	].)/m,
    lookbehind: true,
    alias: "punctuation"
  },
  "url-reference": {
    pattern: /!?\[[^\]]+\]:[ 	]+(?:\S+|<(?:\\.|[^\\>])+>)(?:[ 	]+(?:"(?:\\.|[^\\"])*"|'(?:\\.|[^\\'])*'|\((?:\\.|[^\\)])*\)))?/,
    inside: {
      variable: {
        pattern: /^(!?\[)[^\]]+/,
        lookbehind: true
      },
      string: /(?:"(?:\\.|[^\\"])*"|'(?:\\.|[^\\'])*'|\((?:\\.|[^\\)])*\))$/,
      punctuation: /^[[\]!:]|<|>/
    },
    alias: "url"
  },
  bold: {
    pattern: createInline("\\b__(?:(?!_)<0>|_(?:(?!_)<0>)+_)+__\\b|\\*\\*(?:(?!\\*)<0>|\\*(?:(?!\\*)<0>)+\\*)+\\*\\*"),
    lookbehind: true,
    inside: {
      content: {
        pattern: /(^..)[^]+(?=..)/,
        lookbehind: true,
        inside: {}
      },
      punctuation: /../
    }
  },
  italic: {
    pattern: createInline("\\b_(?:(?!_)<0>|__(?:(?!_)<0>)+__)+_\\b|\\*(?:(?!\\*)<0>|\\*\\*(?:(?!\\*)<0>)+\\*\\*)+\\*"),
    lookbehind: true,
    inside: {
      content: {
        pattern: /(?!^)[^]+(?=.)/,
        inside: {}
      },
      punctuation: /./
    }
  },
  strike: {
    pattern: createInline("(~~?)(?:(?!~)<0>)+\\2"),
    lookbehind: true,
    inside: {
      punctuation: /^~~?|~~?$/,
      content: {
        pattern: /[^]+/,
        inside: {}
      }
    }
  },
  "code-snippet": {
    pattern: /(^|[^\\`])(`+)[^\n`](?:|.*?[^\n`])\2(?!`)/g,
    lookbehind: true,
    alias: "code keyword"
  },
  url: {
    pattern: createInline('!?\\[(?:(?!\\])<0>)+\\](?:\\([^\\s)]+(?:[ \t]+"(?:\\\\.|[^\\\\"])*")?\\)|[ \t]?\\[(?:(?!\\])<0>)+\\])'),
    lookbehind: true,
    inside: {
      operator: /^!/,
      content: {
        pattern: /(^\[)[^\]]+(?=\])/,
        lookbehind: true,
        inside: {}
      },
      variable: {
        pattern: /(^\][ 	]?\[)[^\]]+(?=\]$)/,
        lookbehind: true
      },
      url: {
        pattern: /(^\]\()[^\s)]+/,
        lookbehind: true
      },
      string: {
        pattern: /(^[ 	]+)"(?:\\.|[^\\"])*"(?=\)$)/,
        lookbehind: true
      },
      "markup-bracket": markdown["markup-bracket"]
    }
  }
});
[
  "url",
  "bold",
  "italic",
  "strike"
].forEach((token) => {
  [
    "url",
    "bold",
    "italic",
    "strike",
    "code-snippet",
    "markup-bracket"
  ].forEach((inside) => {
    if (token != inside)
      markdown[token].inside.content.inside[inside] = markdown[inside];
  });
});
