var z=(b,k)=>{for(var q=0;q<k;q++)b=b.replace(/<self>/g,`(?:${b})`);return b.replace(/<self>/g,"[]")},y=(b,k)=>b.replace(/<(\d+)>/g,(q,v)=>`(?:${k[+v]})`),B=(b,k,q)=>RegExp(y(b,k),q);
export{z as X,y as Y,B as Z};
