import {
  languages
} from "./app-0mckv39t.js";
import"./app-2vd5xdaq.js";

// node_modules/prism-code-editor/dist/prism/languages/ini.js
languages.ini = {
  comment: {
    pattern: /(^[ \f	\v]*)[#;].*/m,
    lookbehind: true
  },
  section: {
    pattern: /(^[ \f	\v]*)\[[^\n\]]*\]?/m,
    lookbehind: true,
    inside: {
      "section-name": {
        pattern: /(^\[[ \f	\v]*)[^ \f	\v\]]+(?:[ \f	\v]+[^ \f	\v\]]+)*/,
        lookbehind: true,
        alias: "selector"
      },
      punctuation: /[[\]]/
    }
  },
  key: {
    pattern: /(^[ \f	\v]*)[^ \f\n	\v=]+(?:[ \f	\v]+[^ \f\n	\v=]+)*(?=[ \f	\v]*=)/m,
    lookbehind: true,
    alias: "attr-name"
  },
  value: {
    pattern: /(=[ \f	\v]*)[^ \f\n	\v]+(?:[ \f	\v]+[^ \f\n	\v]+)*/,
    lookbehind: true,
    alias: "attr-value",
    inside: { "inner-value": {
      pattern: /^(["']).+(?=\1$)/,
      lookbehind: true
    } }
  },
  punctuation: /=/
};
