import {
  languages
} from "./app-0mckv39t.js";
import"./app-2vd5xdaq.js";

// node_modules/prism-code-editor/dist/prism/languages/diff.js
var diff = languages.diff = { coord: /^(?:\*{3}|-{3}|\+{3}|\d).*$|^@@.*@@$/m };
var PREFIXES = {
  "deleted-sign": "-",
  "deleted-arrow": "<",
  "inserted-sign": "\\+",
  "inserted-arrow": ">",
  unchanged: " ",
  diff: "!"
};
for (name in PREFIXES) {
  prefix = name.split("-")[0];
  diff[name] = {
    pattern: RegExp("(?:^" + PREFIXES[name] + `.*
?)+`, "m"),
    alias: prefix != name ? prefix : name == "diff" ? "bold" : undefined,
    inside: { prefix: {
      pattern: RegExp("^" + PREFIXES[name], "mg"),
      alias: prefix
    } }
  };
}
var prefix;
var name;
