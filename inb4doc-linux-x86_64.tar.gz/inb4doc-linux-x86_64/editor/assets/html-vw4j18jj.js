import {
  markupComment,
  markupLanguage,
  xmlOpeningTag
} from "./app-98xjztvq.js";
import {
  languageMap,
  voidTags
} from "./app-9metdmjj.js";
import"./app-gccwp0hh.js";
import"./app-v8v73v6d.js";
import"./app-bdyxzr9h.js";
import"./app-ky8th4fh.js";
import"./app-db5x50nb.js";

// node_modules/prism-code-editor/dist/languages/html.js
languageMap.markup = languageMap.html = languageMap.markdown = languageMap.md = markupLanguage(markupComment, xmlOpeningTag, voidTags);
