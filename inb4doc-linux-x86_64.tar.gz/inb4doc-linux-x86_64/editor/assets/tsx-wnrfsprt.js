import"./app-3xh4ce8z.js";
import"./app-1vs1x09x.js";
import"./app-tt81wz17.js";
import {
  addJsxTag,
  space
} from "./app-xjz2c8ce.js";
import {
  re
} from "./app-v8v73v6d.js";
import"./app-ky8th4fh.js";
import {
  insertBefore
} from "./app-bdyxzr9h.js";
import {
  languages
} from "./app-db5x50nb.js";

// node_modules/prism-code-editor/dist/prism/languages/tsx.js
var tsx = addJsxTag(languages.ts, "tsx");
var tag = tsx["tag"];
var bracket = "(?:^|(";
try {
  bracket += "?<=";
} catch {
  tag.lookbehind = true;
}
tag.pattern = RegExp(bracket + `[^\\w$])|(?=</))${tag.pattern.source.replace(space, space + `|(?:${space})*<(?:[^<>=]|=[^<]|=?<(?:[^<>]|<[^<>]*>)*>)*>`)}`, "g");
insertBefore(tag.inside, "attr-value", { generic: {
  pattern: re("(^<0>*)<(?:[^<>=]|=[^<]|=?<(?:[^<>]|<[^<>]*>)*>)*>", [space]),
  lookbehind: true,
  alias: "class-name",
  inside: tsx["class-name"].inside
} });
