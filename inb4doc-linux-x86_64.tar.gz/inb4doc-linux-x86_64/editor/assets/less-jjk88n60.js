import"./app-d21z8wha.js";
import {
  extend,
  insertBefore
} from "./app-086jmyb9.js";
import {
  clikeComment
} from "./app-ky8th4fh.js";
import {
  languages
} from "./app-0mckv39t.js";
import"./app-2vd5xdaq.js";

// node_modules/prism-code-editor/dist/prism/languages/less.js
insertBefore(languages.less = extend("css", {
  comment: clikeComment,
  atrule: {
    pattern: /@[\w-](?:\((?:[^(){}]|\([^(){}]*\))*\)|[^(){};\s]|\s+(?!\s))*?(?=\s*\{)/,
    inside: { punctuation: /[():]/ }
  },
  selector: {
    pattern: /(?:@\{[\w-]+\}|[^{};\s@])(?:@\{[\w-]+\}|\((?:[^(){}]|\([^(){}]*\))*\)|[^(){};@\s]|\s+(?!\s))*?(?=\s*\{)/,
    inside: { variable: /@+[\w-]+/ }
  },
  variable: [{
    pattern: /@[\w-]+\s*:/,
    inside: { punctuation: /:/ }
  }, /@@?[\w-]+/],
  property: /(?:@\{[\w-]+\}|[\w-])+(?:\+_?)?(?=\s*:)/,
  operator: /[/*+-]/
}), "property", { "mixin-usage": {
  pattern: /([{;]\s*)[.#](?!\d)[\w-].*?(?=[(;])/,
  lookbehind: true,
  alias: "function"
} });
