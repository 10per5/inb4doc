// src/entities/Image.ts
class Image {
  id;
  dir;
  file;
  blobUrl;
  url;
  storageUrl;
  usedIn = [];
  constructor(id, dir, file) {
    this.id = id;
    this.dir = dir;
    this.file = file;
  }
  get name() {
    return this.id;
  }
  get isPending() {
    return this.url === undefined;
  }
  commit(url, storageUrl) {
    this.revokeBlobUrl();
    this.file = undefined;
    this.url = url;
    if (storageUrl)
      this.storageUrl = storageUrl;
  }
  revokeBlobUrl() {
    if (this.blobUrl) {
      URL.revokeObjectURL(this.blobUrl);
      this.blobUrl = undefined;
    }
  }
  static fromRecord(record) {
    const img = new Image(record.id, record.dir, record.file);
    img.blobUrl = URL.createObjectURL(record.file);
    return img;
  }
  static fromEntry(entry, dir) {
    const img = new Image(entry.name, dir);
    img.url = entry.url;
    img.storageUrl = entry.storageUrl;
    img.usedIn = [...entry.usedIn];
    return img;
  }
}

// lib/build/build-mode.ts
var BUILD_MODE_NAMES = {
  [1 /* WebRemote */]: "web-remote",
  [2 /* WebLocal */]: "web-local",
  [4 /* GuiDesktop */]: "gui-desktop",
  [8 /* GuiMobile */]: "gui-mobile"
};
var NAME_TO_BUILD_MODE = Object.fromEntries(Object.entries(BUILD_MODE_NAMES).map(([mode, name]) => [name, Number(mode)]));
var SUPPORTED_MODES = {
  [1 /* AllowProbe */]: 2 /* WebLocal */ | 4 /* GuiDesktop */ | 8 /* GuiMobile */,
  [2 /* DefaultToRemote */]: 2 /* WebLocal */ | 4 /* GuiDesktop */ | 8 /* GuiMobile */,
  [4 /* MobileCss */]: 2 /* WebLocal */ | 8 /* GuiMobile */,
  [8 /* ToolbarMobile */]: 2 /* WebLocal */ | 8 /* GuiMobile */,
  [16 /* SidebarGestures */]: 8 /* GuiMobile */,
  [32 /* MetaPanelCompact */]: 8 /* GuiMobile */,
  [64 /* DevOverlay */]: 4 /* GuiDesktop */,
  [128 /* LivePreview */]: 1 /* WebRemote */ | 2 /* WebLocal */ | 4 /* GuiDesktop */
};
var _currentMode = null;
function getCurrentMode() {
  if (_currentMode === null) {
    const raw = document.documentElement.dataset.buildMode;
    _currentMode = NAME_TO_BUILD_MODE[raw || ""] ?? 2 /* WebLocal */;
  }
  return _currentMode;
}
function hasFunc(func) {
  return !!(SUPPORTED_MODES[func] & getCurrentMode());
}

// src/stores/connection-store.ts
var STORAGE_KEY = "inb4doc-connection";
var DEFAULTS = {
  host: "localhost",
  port: 3000
};
function load() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw)
      return { ...DEFAULTS, ...JSON.parse(raw) };
  } catch {}
  return null;
}
function save(config) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
  } catch {}
}

class ConnectionStore {
  config = load();
  _remoteAvailable = false;
  getHost() {
    return this.config?.host ?? DEFAULTS.host;
  }
  getPort() {
    return this.config?.port ?? DEFAULTS.port;
  }
  getConfig() {
    return this.config ? { ...this.config } : { ...DEFAULTS };
  }
  setConfig(host, port) {
    this.config = { host, port };
    save(this.config);
    this._remoteAvailable = false;
  }
  isCustom() {
    return this.config !== null;
  }
  getBaseUrl() {
    return `http://${this.getHost()}:${this.getPort()}`;
  }
  get remoteAvailable() {
    return this._remoteAvailable;
  }
  set remoteAvailable(v) {
    this._remoteAvailable = v;
  }
  isAppScheme() {
    const host = this.config?.host ?? "";
    return host.startsWith("app://");
  }
  isInsideAppGui() {
    return typeof window !== "undefined" && window.location.protocol === "app:";
  }
  async probe(timeout = 3000) {
    if (this.isAppScheme() || this.isInsideAppGui() || !hasFunc(1 /* AllowProbe */)) {
      this._remoteAvailable = false;
      return false;
    }
    const controller = new AbortController;
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const res = await fetch(this.getBaseUrl() + "/api/tree", {
        method: "HEAD",
        signal: controller.signal
      });
      clearTimeout(timer);
      this._remoteAvailable = res.ok || res.status === 200;
    } catch {
      clearTimeout(timer);
      this._remoteAvailable = false;
    }
    return this._remoteAvailable;
  }
}
var connectionStore = new ConnectionStore;

// src/providers/remote-provider.ts
class RemoteProvider {
  name = "remote";
  get appFallback() {
    if (typeof window !== "undefined" && window.location.protocol === "app:") {
      return !connectionStore.remoteAvailable;
    }
    const host = connectionStore.getHost();
    return host === "app://" || host === "app://_" || host.startsWith("app://_/");
  }
  url(path) {
    if (this.appFallback) {
      return path;
    }
    return `${connectionStore.getBaseUrl()}${path}`;
  }
  async isAvailable() {
    if (await connectionStore.probe()) {
      return true;
    }
    return this.appFallback;
  }
  async getTree() {
    const res = await fetch(this.url("/api/tree"));
    if (!res.ok)
      return {};
    return res.json();
  }
  async readFile(path) {
    const res = await fetch(this.url(`/content/${path}.md`));
    if (!res.ok)
      return null;
    return res.text();
  }
  async writeFile(path, content) {
    await fetch(this.url(`/content/${path}.md`), {
      method: "PUT",
      headers: { "Content-Type": "text/markdown" },
      body: content
    });
  }
  async deleteFile(path) {
    await fetch(this.url(`/content/${path}.md`), { method: "DELETE" });
  }
  async moveFile(from, to) {
    const res = await fetch(this.url("/api/move"), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ from: `${from}.md`, to: `${to}.md` })
    });
    if (!res.ok)
      throw new Error(`Move failed: ${res.status}`);
  }
  async search(query) {
    const res = await fetch(this.url("/api/search"), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query })
    });
    if (!res.ok)
      return [];
    const data = await res.json();
    return data.results ?? [];
  }
  async getServerTime(path) {
    const res = await fetch(this.url(`/content/${path}.md`), { method: "HEAD" });
    if (!res.ok)
      return null;
    const lastModified = res.headers.get("Last-Modified");
    if (!lastModified)
      return null;
    return new Date(lastModified).getTime();
  }
  async uploadImage(file, dir) {
    const form = new FormData;
    form.append("file", file);
    form.append("dir", dir);
    const resp = await fetch(this.url("/api/upload"), { method: "POST", body: form });
    if (!resp.ok)
      throw new Error(`Upload failed: ${resp.statusText}`);
    const result = await resp.json();
    return result.url;
  }
  async listImages(dir, refs) {
    const params = new URLSearchParams({ dir });
    if (refs)
      params.set("refs", "true");
    const resp = await fetch(this.url(`/api/images?${params}`));
    if (!resp.ok)
      throw new Error(`Failed to list images: ${resp.statusText}`);
    const data = await resp.json();
    return data.images.map((img) => ({
      name: img.name,
      url: img.url,
      storageUrl: `image/${img.name}`,
      usedIn: img.usedIn || []
    }));
  }
  resolveImageUrl(url) {
    return;
  }
  async deleteImage(name, dir) {
    const resp = await fetch(this.url(`/api/images/${encodeURIComponent(name)}?dir=${encodeURIComponent(dir)}`), {
      method: "DELETE"
    });
    if (!resp.ok)
      throw new Error(`Failed to delete image: ${resp.statusText}`);
  }
}

// src/utils/content-search.ts
function contentMatches(content, query) {
  return content.toLowerCase().includes(query.toLowerCase().trim());
}
function extractTableCells(table, query) {
  const q = query.toLowerCase();
  const rows = table.split(`
`).filter((r) => r.trim().startsWith("|") && !r.includes("---"));
  const results = [];
  for (let ri = 0;ri < rows.length; ri++) {
    const cells = rows[ri].split("|").slice(1, -1).map((c) => c.trim());
    for (let ci = 0;ci < cells.length; ci++) {
      if (cells[ci].toLowerCase().includes(q)) {
        results.push(cells[ci]);
      }
    }
  }
  return results;
}
function extractSnippets(content, query, maxSnippets = 3) {
  const q = query.toLowerCase().trim();
  if (!q)
    return [];
  const paragraphs = content.split(/\n\s*\n/);
  const snippets = [];
  for (const para of paragraphs) {
    if (para.toLowerCase().includes(q)) {
      if (para.trim().startsWith("|")) {
        const cells = extractTableCells(para, q);
        snippets.push(...cells);
      } else {
        snippets.push(para.trim());
      }
      if (snippets.length >= maxSnippets)
        break;
    }
  }
  return snippets;
}

// src/utils/sanitize.ts
var ALLOWED_IMG_EXTS = ["png", "jpg", "jpeg", "gif", "svg", "webp", "bmp", "ico"];
function sanitizeImageName(name) {
  const dot = name.lastIndexOf(".");
  const rawExt = dot >= 0 ? name.slice(dot).toLowerCase() : "";
  const extBody = rawExt.replace(".", "");
  const safeExt = ALLOWED_IMG_EXTS.includes(extBody) ? rawExt : ".png";
  const base = (dot >= 0 ? name.slice(0, dot) : name).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 40);
  const suffix = Math.random().toString(36).slice(2, 8);
  return `${base || "image"}-${suffix}${safeExt}`;
}

// src/providers/fs-provider.ts
class FileSystemProvider {
  name = "fs";
  dirHandle = null;
  imageUrlCache = new Map;
  currentDir = "";
  async isAvailable() {
    return typeof window.showDirectoryPicker === "function";
  }
  async init() {
    if (this.dirHandle)
      return;
    this.dirHandle = await window.showDirectoryPicker();
  }
  async getTree() {
    if (!this.dirHandle)
      await this.init();
    const result = {};
    await this.buildTree(this.dirHandle, result);
    return result;
  }
  async buildTree(dir, out) {
    for await (const entry of dir.values()) {
      if (entry.name.startsWith("."))
        continue;
      if (entry.kind === "directory") {
        const children = {};
        await this.buildTree(entry, children);
        if (Object.keys(children).length > 0) {
          out[entry.name] = children;
        }
      } else if (entry.name.endsWith(".md")) {
        const file = await entry.getFile();
        const text = await file.text();
        const match = text.match(/^---\n([\s\S]*?)\n---/);
        if (match) {
          const weightMatch = match[1].match(/^weight:\s*(\d+)/m);
          if (weightMatch) {
            out[entry.name] = { weight: parseInt(weightMatch[1], 10) };
            continue;
          }
        }
        out[entry.name] = null;
      }
    }
  }
  async readFile(path) {
    if (!this.dirHandle)
      await this.init();
    const parts = path.split("/").filter(Boolean);
    let current = this.dirHandle;
    for (let i = 0;i < parts.length - 1; i++) {
      current = await current.getDirectoryHandle(parts[i]);
    }
    const fileName = parts[parts.length - 1] + ".md";
    try {
      const fileHandle = await current.getFileHandle(fileName);
      const file = await fileHandle.getFile();
      return await file.text();
    } catch {
      return null;
    }
  }
  async writeFile(path, content) {
    if (!this.dirHandle)
      await this.init();
    const parts = path.split("/").filter(Boolean);
    let current = this.dirHandle;
    for (let i = 0;i < parts.length - 1; i++) {
      current = await current.getDirectoryHandle(parts[i], { create: true });
    }
    const fileName = parts[parts.length - 1] + ".md";
    const fileHandle = await current.getFileHandle(fileName, { create: true });
    const writable = await fileHandle.createWritable();
    await writable.write(content);
    await writable.close();
  }
  async deleteFile(path) {
    if (!this.dirHandle)
      await this.init();
    const parts = path.split("/").filter(Boolean);
    const dir = parts.slice(0, -1).join("/");
    let current = this.dirHandle;
    for (let i = 0;i < parts.length - 1; i++) {
      current = await current.getDirectoryHandle(parts[i]);
    }
    const fileName = parts[parts.length - 1] + ".md";
    await current.removeEntry(fileName);
    await this.cleanupEmptyParents(current, parts.slice(0, -1));
    await this.removeOrphanedImages(dir);
  }
  async cleanupEmptyParents(dir, parts) {
    if (parts.length === 0)
      return;
    for await (const _ of dir.values()) {
      return;
    }
    const parentName = parts.pop();
    if (!parentName)
      return;
    const parent = await this.getParentDir(parts);
    if (parent) {
      try {
        await parent.removeEntry(parentName);
        await this.cleanupEmptyParents(parent, parts);
      } catch {}
    }
  }
  async getParentDir(parts) {
    if (!this.dirHandle)
      return null;
    if (parts.length === 0)
      return this.dirHandle;
    let current = this.dirHandle;
    for (const part of parts) {
      try {
        current = await current.getDirectoryHandle(part);
      } catch {
        return null;
      }
    }
    return current;
  }
  async moveFile(from, to) {
    const content = await this.readFile(from);
    if (content === null)
      throw new Error("Source not found");
    await this.writeFile(to, content);
    await this.deleteFile(from);
  }
  async search(query) {
    if (!this.dirHandle)
      await this.init();
    return this.searchInDir(this.dirHandle, "", query);
  }
  async searchInDir(dir, prefix, query) {
    const results = [];
    for await (const entry of dir.values()) {
      if (entry.name.startsWith("."))
        continue;
      if (entry.kind === "directory") {
        if (entry.name === "image")
          continue;
        const sub = await this.searchInDir(entry, prefix ? `${prefix}/${entry.name}` : entry.name, query);
        results.push(...sub);
      } else if (entry.name.endsWith(".md")) {
        const file = await entry.getFile();
        const body = await file.text();
        if (contentMatches(body, query)) {
          const full = prefix ? `${prefix}/${entry.name}` : entry.name;
          results.push({
            path: full.replace(/\.md$/, ""),
            snippets: extractSnippets(body, query)
          });
        }
      }
    }
    return results;
  }
  async getServerTime(path) {
    if (!this.dirHandle)
      await this.init();
    const parts = path.split("/").filter(Boolean);
    let current = this.dirHandle;
    for (let i = 0;i < parts.length - 1; i++) {
      current = await current.getDirectoryHandle(parts[i]);
    }
    const fileName = parts[parts.length - 1] + ".md";
    try {
      const fileHandle = await current.getFileHandle(fileName);
      const file = await fileHandle.getFile();
      return file.lastModified;
    } catch {
      return null;
    }
  }
  async ensureImageDir(dir) {
    if (!this.dirHandle)
      await this.init();
    const parts = dir.split("/").filter(Boolean);
    let current = this.dirHandle;
    for (const part of parts) {
      current = await current.getDirectoryHandle(part, { create: true });
    }
    return await current.getDirectoryHandle("image", { create: true });
  }
  async uploadImage(file, dir) {
    const name = sanitizeImageName(file.name);
    const relPath = `image/${name}`;
    const imageDir = await this.ensureImageDir(dir);
    const fileHandle = await imageDir.getFileHandle(name, { create: true });
    const writable = await fileHandle.createWritable();
    await writable.write(file);
    await writable.close();
    const blobUrl = URL.createObjectURL(file);
    this.imageUrlCache.set(`${dir}/${relPath}`, blobUrl);
    return relPath;
  }
  resolveImageUrl(url) {
    const exact = this.imageUrlCache.get(url);
    if (exact)
      return exact;
    if (this.currentDir) {
      return this.imageUrlCache.get(`${this.currentDir}/${url}`);
    }
    return;
  }
  async listImages(dir, refs) {
    this.currentDir = dir;
    let imageDir;
    try {
      imageDir = await this.ensureImageDir(dir);
    } catch {
      return [];
    }
    const entries = [];
    const imageNames = [];
    for await (const entry of imageDir.values()) {
      if (entry.kind !== "file")
        continue;
      const name = entry.name;
      const ext = name.includes(".") ? name.split(".").pop().toLowerCase() : "";
      if (!["png", "jpg", "jpeg", "gif", "svg", "webp", "bmp", "ico"].includes(ext))
        continue;
      imageNames.push(name);
    }
    imageNames.sort();
    const scanDir = dir ? dir : "";
    const mdFiles = refs ? await this.collectMdFiles(scanDir) : new Map;
    for (const name of imageNames) {
      const storageUrl = `image/${name}`;
      const cacheKey = `${dir}/${storageUrl}`;
      let displayUrl = this.imageUrlCache.get(cacheKey);
      if (!displayUrl) {
        displayUrl = this.imageUrlCache.get(storageUrl);
      }
      if (!displayUrl) {
        try {
          const imageDir2 = await this.ensureImageDir(dir);
          const fileHandle = await imageDir2.getFileHandle(name);
          const file = await fileHandle.getFile();
          displayUrl = URL.createObjectURL(file);
          this.imageUrlCache.set(cacheKey, displayUrl);
        } catch {
          displayUrl = "";
        }
      }
      const usedIn = refs ? this.findRefsInFiles(name, mdFiles) : [];
      entries.push({ name, url: displayUrl, storageUrl, usedIn });
    }
    return entries;
  }
  async collectMdFiles(dir) {
    const result = new Map;
    if (!this.dirHandle)
      await this.init();
    async function walk(handle2, prefix, skipImage, out) {
      for await (const entry of handle2.values()) {
        if (entry.name.startsWith("."))
          continue;
        if (entry.kind === "directory") {
          if (skipImage && entry.name === "image")
            continue;
          await walk(entry, prefix ? `${prefix}/${entry.name}` : entry.name, skipImage, out);
        } else if (entry.name.endsWith(".md")) {
          const file = await entry.getFile();
          const text = await file.text();
          const rel = prefix ? `${prefix}/${entry.name}` : entry.name;
          out.set(rel, text);
        }
      }
    }
    let handle = this.dirHandle;
    if (dir) {
      const parts = dir.split("/").filter(Boolean);
      for (const part of parts) {
        handle = await handle.getDirectoryHandle(part);
      }
    }
    await walk(handle, dir, true, result);
    return result;
  }
  findRefsInFiles(imageName, files) {
    const refs = [];
    for (const [relPath, content] of files) {
      if (content.includes(imageName)) {
        refs.push(relPath);
      }
    }
    return refs;
  }
  async deleteImage(name, dir) {
    try {
      const imageDir = await this.ensureImageDir(dir);
      await imageDir.removeEntry(name);
    } catch {}
  }
  async removeOrphanedImages(dir) {
    let imageDir;
    try {
      imageDir = await this.ensureImageDir(dir);
    } catch {
      return;
    }
    const mdFiles = await this.collectMdFiles(dir);
    for await (const entry of imageDir.values()) {
      if (entry.kind !== "file")
        continue;
      const refs = this.findRefsInFiles(entry.name, mdFiles);
      if (refs.length === 0) {
        try {
          await imageDir.removeEntry(entry.name);
        } catch {}
      }
    }
  }
}

// src/providers/local-storage-provider.ts
var STORAGE_PREFIX = "inb4doc:";
var IMAGE_PREFIX = "inb4doc:image:";

class LocalStorageProvider {
  name = "localStorage";
  async isAvailable() {
    return true;
  }
  async getTree() {
    const result = {};
    const mdKeys = this.getAllMdKeys();
    for (const key of mdKeys) {
      const relPath = key.slice(STORAGE_PREFIX.length);
      const parts = relPath.split("/");
      let current = result;
      for (let i = 0;i < parts.length; i++) {
        const isLeaf = i === parts.length - 1;
        if (isLeaf) {
          const content = localStorage.getItem(key);
          if (content) {
            const match = content.match(/^---\n([\s\S]*?)\n---/);
            if (match) {
              const weightMatch = match[1].match(/^weight:\s*(\d+)/m);
              if (weightMatch) {
                current[parts[i]] = { weight: parseInt(weightMatch[1], 10) };
                continue;
              }
            }
          }
          current[parts[i]] = null;
        } else {
          if (!current[parts[i]] || typeof current[parts[i]] !== "object" || current[parts[i]] === null) {
            current[parts[i]] = {};
          }
          current = current[parts[i]];
        }
      }
    }
    return result;
  }
  getAllMdKeys() {
    const keys = [];
    for (let i = 0;i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith(STORAGE_PREFIX) && key.endsWith(".md")) {
        keys.push(key);
      }
    }
    return keys;
  }
  async readFile(path) {
    return localStorage.getItem(STORAGE_PREFIX + path + ".md");
  }
  async writeFile(path, content) {
    localStorage.setItem(STORAGE_PREFIX + path + ".md", content);
  }
  async deleteFile(path) {
    localStorage.removeItem(STORAGE_PREFIX + path + ".md");
    this.removeOrphanedImages();
  }
  async moveFile(from, to) {
    const content = await this.readFile(from);
    if (content === null)
      throw new Error("Source not found");
    await this.writeFile(to, content);
    await this.deleteFile(from);
  }
  async getServerTime(_path) {
    return Date.now();
  }
  async search(query) {
    const results = [];
    for (let i = 0;i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (!key || !key.startsWith(STORAGE_PREFIX) || !key.endsWith(".md"))
        continue;
      const body = localStorage.getItem(key);
      if (body && contentMatches(body, query)) {
        results.push({
          path: key.slice(STORAGE_PREFIX.length).replace(/\.md$/, ""),
          snippets: extractSnippets(body, query)
        });
      }
    }
    return results;
  }
  async fileToBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader;
      reader.onload = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }
  async uploadImage(file, _dir) {
    const ext = file.name.includes(".") ? file.name.split(".").pop() : "png";
    const name = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
    const base64 = await this.fileToBase64(file);
    localStorage.setItem(IMAGE_PREFIX + name, base64);
    return `inb4doc-image:${name}`;
  }
  async listImages(_dir, refs) {
    const entries = [];
    for (let i = 0;i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith(IMAGE_PREFIX)) {
        const name = key.slice(IMAGE_PREFIX.length);
        const base64 = localStorage.getItem(key);
        const usedIn = refs ? this.findRefs(name) : [];
        entries.push({ name, url: base64, storageUrl: `inb4doc-image:${name}`, usedIn });
      }
    }
    return entries;
  }
  resolveImageUrl(url) {
    if (url.startsWith("inb4doc-image:")) {
      const name = url.slice("inb4doc-image:".length);
      return localStorage.getItem(IMAGE_PREFIX + name) || undefined;
    }
    return;
  }
  findRefs(imageName) {
    const refs = [];
    for (let i = 0;i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith(STORAGE_PREFIX) && key.endsWith(".md")) {
        const content = localStorage.getItem(key);
        if (content && content.includes(`inb4doc-image:${imageName}`)) {
          refs.push(key.slice(STORAGE_PREFIX.length));
        }
      }
    }
    return refs;
  }
  async deleteImage(name, _dir) {
    localStorage.removeItem(IMAGE_PREFIX + name);
  }
  removeOrphanedImages() {
    const imageKeys = [];
    for (let i = 0;i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith(IMAGE_PREFIX)) {
        imageKeys.push(key);
      }
    }
    for (const key of imageKeys) {
      const name = key.slice(IMAGE_PREFIX.length);
      const refs = this.findRefs(name);
      if (refs.length === 0) {
        localStorage.removeItem(key);
      }
    }
  }
}

// src/providers/index.ts
function createProviderByType(type) {
  switch (type) {
    case "remote":
      return new RemoteProvider;
    case "filesystem":
      return new FileSystemProvider;
    case "localStorage":
      return new LocalStorageProvider;
  }
}

// src/entities/PendingOps.ts
class PendingOps {
  ops;
  constructor(saved) {
    this.ops = Array.isArray(saved) && saved.length > 0 ? [...saved] : [];
  }
  get all() {
    return this.ops;
  }
  get count() {
    return this.ops.length;
  }
  queueCreate(path, content) {
    const delIdx = this.ops.findIndex((o) => o.type === "delete" /* Delete */ && o.path === path);
    if (delIdx !== -1) {
      this.ops.splice(delIdx, 1);
    } else {
      this.ops.push({ type: "create" /* Create */, path, content });
    }
  }
  queueDelete(path) {
    const createIdx = this.ops.findIndex((o) => o.type === "create" /* Create */ && o.path === path);
    if (createIdx !== -1) {
      this.ops.splice(createIdx, 1);
    } else {
      this.ops.push({ type: "delete" /* Delete */, path });
    }
  }
  queueRename(from, to, content) {
    this.ops.push({ type: "rename" /* Rename */, from, to, ...content ? { content } : {} });
  }
  queueMove(from, to, content) {
    this.ops.push({ type: "move" /* Move */, from, to, ...content ? { content } : {} });
  }
  clear() {
    this.ops = [];
  }
  hasPendingDelete(path) {
    return this.ops.some((o) => o.type === "delete" /* Delete */ && o.path === path);
  }
  hasPendingCreate(path) {
    return this.ops.some((o) => o.type === "create" /* Create */ && o.path === path);
  }
  hasPendingMoveTo(path) {
    return this.ops.some((o) => (o.type === "move" /* Move */ || o.type === "rename" /* Rename */) && o.to === path);
  }
  applyToTree(tree) {
    return applyPendingOps(tree, this.ops);
  }
}

// src/utils/tree.ts
function collectLeaves(tree, prefix = "") {
  const leaves = [];
  for (const [key, val] of Object.entries(tree)) {
    const fullPath = prefix ? `${prefix}/${key}` : key;
    if (val === null || typeof val === "object" && "weight" in val) {
      leaves.push(fullPath.replace(/\.md$/, ""));
    } else if (typeof val === "object" && val !== null) {
      leaves.push(...collectLeaves(val, fullPath));
    }
  }
  return leaves;
}
function setPath(tree, path) {
  const parts = path.split("/");
  let node = tree;
  for (let i = 0;i < parts.length; i++) {
    const part = parts[i];
    if (i === parts.length - 1) {
      if (!(part in node) && !(`${part}.md` in node)) {
        node[part] = null;
      }
    } else {
      if (!(part in node) || node[part] === null) {
        node[part] = {};
      }
      node = node[part];
    }
  }
}
function removePath(tree, path) {
  const parts = path.split("/");
  let node = tree;
  for (let i = 0;i < parts.length - 1; i++) {
    const part = parts[i];
    if (!(part in node) || node[part] === null)
      return;
    node = node[part];
  }
  const last = parts[parts.length - 1];
  if (last in node) {
    delete node[last];
  } else if (`${last}.md` in node) {
    delete node[`${last}.md`];
  }
}
function applyPendingOps(tree, ops) {
  if (ops.length === 0)
    return tree;
  const result = JSON.parse(JSON.stringify(tree));
  for (const op of ops) {
    switch (op.type) {
      case "create" /* Create */:
        setPath(result, op.path);
        break;
      case "delete" /* Delete */:
        break;
      case "rename" /* Rename */:
        removePath(result, op.from);
        setPath(result, op.to);
        break;
      case "move" /* Move */:
        removePath(result, op.from);
        setPath(result, op.to);
        break;
    }
  }
  return result;
}

// src/stores/tree-store.ts
class TreeStore {
  tree = {};
  setTree(tree) {
    this.tree = tree;
  }
  getTree() {
    return this.tree;
  }
  afterWrite(path) {
    setPath(this.tree, path);
  }
  afterDelete(path) {
    removePath(this.tree, path);
  }
  afterMove(from, to) {
    removePath(this.tree, from);
    setPath(this.tree, to);
  }
  isEmpty() {
    return Object.keys(this.tree).length === 0;
  }
}
var treeStore = new TreeStore;

// src/stores/app-events.ts
class EventBus {
  listeners = new Map;
  on(event, handler) {
    if (!this.listeners.has(event))
      this.listeners.set(event, new Set);
    this.listeners.get(event).add(handler);
    return () => {
      this.listeners.get(event)?.delete(handler);
    };
  }
  emit(event, ...args) {
    this.listeners.get(event)?.forEach((handler) => handler(args[0]));
  }
  off(event, handler) {
    this.listeners.get(event)?.delete(handler);
  }
  removeAll() {
    this.listeners.clear();
  }
}
var appEvents = new EventBus;

// src/stores/provider-store.ts
var LAST_PROVIDER_KEY = "inb4doc-last-provider";
var globalProvider = null;
function setProvider(provider) {
  globalProvider = provider;
}
function getProvider() {
  if (!globalProvider)
    throw new Error("ContentProvider not initialized");
  return globalProvider;
}
function saveLastProvider(type) {
  try {
    localStorage.setItem(LAST_PROVIDER_KEY, type);
  } catch {}
}
function loadLastProvider() {
  try {
    const v = localStorage.getItem(LAST_PROVIDER_KEY);
    if (v === "remote" || v === "filesystem" || v === "localStorage")
      return v;
  } catch {}
  return null;
}
async function initializeProvider() {
  const last = loadLastProvider();
  const defaultToRemote = hasFunc(2 /* DefaultToRemote */);
  const base = defaultToRemote ? ["remote", "filesystem", "localStorage"] : ["localStorage", "filesystem"];
  const candidates = last ? [last, ...base.filter((t) => t !== last)] : base;
  let provider = null;
  for (const type of candidates) {
    const p = createProviderByType(type);
    if (await p.isAvailable()) {
      provider = p;
      break;
    }
  }
  if (!provider)
    provider = createProviderByType("localStorage");
  setProvider(provider);
  try {
    treeStore.setTree(await provider.getTree());
  } catch (e) {
    console.warn("[content] failed to load tree, starting empty:", e);
    treeStore.setTree({});
  }
}
async function switchProvider(type) {
  const provider = createProviderByType(type);
  setProvider(provider);
  saveLastProvider(type);
  treeStore.setTree({});
  try {
    treeStore.setTree(await provider.getTree());
  } catch (e) {
    console.warn("[content] failed to load tree from new provider:", e);
  }
  const pdi = getProviderDisplayInfo(type);
  appEvents.emit("provider-changed" /* ProviderChanged */, { type, icon: pdi.icon, label: pdi.label });
}
async function getAvailableProviders() {
  const remote = createProviderByType("remote");
  const fs = createProviderByType("filesystem");
  const ls = createProviderByType("localStorage");
  const [remoteReachable, fsOk, lsOk] = await Promise.all([
    connectionStore.probe(),
    fs.isAvailable(),
    ls.isAvailable()
  ]);
  const remoteFallback = remote.appFallback;
  const guiFallback = !remoteReachable && !remoteFallback && connectionStore.isInsideAppGui();
  return [
    {
      type: "remote",
      description: "Files served from a backend server via HTTP API",
      available: remoteReachable,
      appFallback: remoteFallback,
      guiFallback,
      reason: remoteReachable ? undefined : remoteFallback ? "inb4doc app://_/ endpoint is used" : guiFallback ? "ℹ️ inb4doc-gui local API is used" : "No content server detected"
    },
    {
      type: "filesystem",
      description: "Access local markdown files via the File System Access API (Chrome/Edge)",
      available: fsOk,
      reason: fsOk ? undefined : "Not supported in this browser (use Chrome or Edge)"
    },
    {
      type: "localStorage",
      description: "Store files in browser local storage — persists across sessions",
      available: lsOk
    }
  ];
}
function cacheKeyForProvider(name) {
  const map = {
    remote: "remote",
    fs: "filesystem",
    localStorage: "localStorage"
  };
  return map[name] || name;
}
function getProviderDisplayInfo(name) {
  const map = {
    remote: { icon: "☁️", label: "Server (Remote)", type: "remote" },
    fs: { icon: "\uD83D\uDCBB", label: "Local Files", type: "filesystem" },
    localStorage: { icon: "\uD83D\uDDC4️", label: "Browser Storage", type: "localStorage" }
  };
  return map[name] || { icon: "❓", label: name, type: name };
}

// src/utils/storage.ts
var PREFS_KEY = "inb4doc-prefs";
var PENDING_OPS_KEY = "inb4doc-pending-ops";
var DEFAULTS2 = { stickyToolbar: true, imageStorageMode: "file", darkMode: false };
function systemPrefersDark() {
  return window.matchMedia("(prefers-color-scheme: dark)").matches;
}
function loadPrefs() {
  try {
    const raw = localStorage.getItem(PREFS_KEY);
    if (raw)
      return { ...DEFAULTS2, ...JSON.parse(raw) };
  } catch {}
  return { ...DEFAULTS2, darkMode: systemPrefersDark() };
}
function savePrefs(prefs) {
  localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
}
function savePendingOps(ops, providerKey) {
  const key = providerKey ? `${PENDING_OPS_KEY}-${providerKey}` : PENDING_OPS_KEY;
  try {
    localStorage.setItem(key, JSON.stringify(ops));
  } catch {}
}
function loadPendingOps(providerKey) {
  const key = providerKey ? `${PENDING_OPS_KEY}-${providerKey}` : PENDING_OPS_KEY;
  try {
    const raw = localStorage.getItem(key);
    if (raw)
      return JSON.parse(raw);
  } catch {}
  return [];
}
function clearPendingOpsStorage(providerKey) {
  const key = providerKey ? `${PENDING_OPS_KEY}-${providerKey}` : PENDING_OPS_KEY;
  localStorage.removeItem(key);
}

// src/utils/file.ts
function readFileAsBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader;
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// src/repositories/imageRepository.ts
var DB_NAME = "inb4doc-pending-images";
var STORE_NAME = "images";
var DB_VERSION = 1;
function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      request.result.createObjectStore(STORE_NAME, { keyPath: "id" });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}
async function saveRecord(record) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    tx.objectStore(STORE_NAME).put(record);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}
async function loadAllRecords() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readonly");
    const request = tx.objectStore(STORE_NAME).getAll();
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}
async function removeRecordById(id) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    tx.objectStore(STORE_NAME).delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

class ImageRepository {
  pendingByDir = new Map;
  knownByDir = new Map;
  counter = 0;
  currentDocDir = "";
  setCurrentDocDir(dir) {
    this.currentDocDir = dir;
  }
  getCurrentDocDir() {
    return this.currentDocDir;
  }
  async restoreFromStorage() {
    const records = await loadAllRecords();
    for (const r of records) {
      const img = Image.fromRecord(r);
      const list = this.pendingByDir.get(r.dir) || [];
      list.push(img);
      this.pendingByDir.set(r.dir, list);
      if (r.id.startsWith("pi-")) {
        const num = parseInt(r.id.slice(3), 10);
        if (num > this.counter)
          this.counter = num;
      }
    }
  }
  isBase64Mode() {
    return loadPrefs().imageStorageMode === "base64";
  }
  async uploadImage(file) {
    if (this.isBase64Mode()) {
      return readFileAsBase64(file);
    }
    const provider = getProvider();
    if (provider.uploadImage) {
      return this.addPending(file, this.currentDocDir);
    }
    return readFileAsBase64(file);
  }
  async addPending(file, dir) {
    const id = `pi-${++this.counter}`;
    const img = new Image(id, dir, file);
    img.blobUrl = URL.createObjectURL(file);
    const list = this.pendingByDir.get(dir) || [];
    list.push(img);
    this.pendingByDir.set(dir, list);
    try {
      await saveRecord({ id, dir, file });
    } catch {}
    return `pending-image:${id}`;
  }
  async commitPendingImages(dir) {
    if (!this.hasPending(dir))
      return new Map;
    const provider = getProvider();
    const upload = async (file, d) => {
      if (provider.uploadImage) {
        return provider.uploadImage(file, d);
      }
      return readFileAsBase64(file);
    };
    return this.commitPending(dir, upload);
  }
  async commitAllPendingImages() {
    const combined = new Map;
    const dirs = this.getAllPendingDirs();
    for (const dir of dirs) {
      const map = await this.commitPendingImages(dir);
      for (const [k, v] of map) {
        combined.set(k, v);
      }
    }
    return combined;
  }
  async commitPending(dir, upload) {
    const list = this.pendingByDir.get(dir) || [];
    const urlMap = new Map;
    for (const img of list) {
      const url = await upload(img.file, dir);
      urlMap.set(`pending-image:${img.id}`, url);
      img.commit(url);
      try {
        await removeRecordById(img.id);
      } catch {}
    }
    this.pendingByDir.delete(dir);
    return urlMap;
  }
  getPending(dir) {
    return this.pendingByDir.get(dir) || [];
  }
  hasPending(dir) {
    return (this.pendingByDir.get(dir) || []).length > 0;
  }
  getAllPendingDirs() {
    return Array.from(this.pendingByDir.keys());
  }
  getBlobUrl(id) {
    for (const list of this.pendingByDir.values()) {
      const found = list.find((p) => p.id === id);
      if (found)
        return found.blobUrl;
    }
    return;
  }
  async removePending(id) {
    for (const [dir, list] of this.pendingByDir) {
      const idx = list.findIndex((p) => p.id === id);
      if (idx !== -1) {
        list[idx].revokeBlobUrl();
        list.splice(idx, 1);
        if (list.length === 0)
          this.pendingByDir.delete(dir);
        try {
          await removeRecordById(id);
        } catch {}
        return true;
      }
    }
    return false;
  }
  async removeAllForDir(dir) {
    const list = this.pendingByDir.get(dir);
    if (list) {
      for (const img of list) {
        img.revokeBlobUrl();
        try {
          await removeRecordById(img.id);
        } catch {}
      }
      this.pendingByDir.delete(dir);
    }
  }
  async remapDir(oldDir, newDir) {
    const list = this.pendingByDir.get(oldDir);
    if (!list || list.length === 0)
      return;
    for (const img of list) {
      img.dir = newDir;
      try {
        await removeRecordById(img.id);
        await saveRecord({ id: img.id, dir: newDir, file: img.file });
      } catch {}
    }
    this.pendingByDir.set(newDir, list);
    this.pendingByDir.delete(oldDir);
  }
  setKnown(dir, entries) {
    this.knownByDir.set(dir, entries.map((e) => Image.fromEntry(e, dir)));
  }
  getKnown(dir) {
    return this.knownByDir.get(dir) || [];
  }
  removeKnown(dir, name) {
    const list = this.knownByDir.get(dir);
    if (!list)
      return false;
    const idx = list.findIndex((k) => k.id === name);
    if (idx === -1)
      return false;
    list.splice(idx, 1);
    return true;
  }
  async listImages(refs) {
    const provider = getProvider();
    if (provider.listImages) {
      const known = await provider.listImages(this.currentDocDir, refs);
      this.setKnown(this.currentDocDir, known);
      return known;
    }
    return [];
  }
  getAllImages() {
    const known = this.getKnown(this.currentDocDir).map((img) => ({
      name: img.name,
      url: img.url,
      storageUrl: img.storageUrl,
      usedIn: img.usedIn
    }));
    const pending = this.getPending(this.currentDocDir).map((p) => ({
      name: p.id,
      url: p.blobUrl,
      storageUrl: p.blobUrl,
      usedIn: [],
      pending: true
    }));
    return [...known, ...pending];
  }
  async deleteImage(name) {
    if (name.startsWith("pi-")) {
      await this.removePending(name);
      return;
    }
    const provider = getProvider();
    if (provider.deleteImage) {
      return provider.deleteImage(name, this.currentDocDir);
    }
  }
}
var imageRepository = new ImageRepository;

export { loadPrefs, savePrefs, savePendingOps, loadPendingOps, clearPendingOpsStorage, appEvents, collectLeaves, PendingOps, connectionStore, extractSnippets, treeStore, getProvider, initializeProvider, switchProvider, getAvailableProviders, cacheKeyForProvider, getProviderDisplayInfo, imageRepository };
