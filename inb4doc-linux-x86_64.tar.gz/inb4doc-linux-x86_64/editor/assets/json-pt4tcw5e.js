import {
  boolean,
  clikeComment
} from "./app-ky8th4fh.js";
import {
  languages
} from "./app-0mckv39t.js";
import"./app-2vd5xdaq.js";

// node_modules/prism-code-editor/dist/prism/languages/json.js
languages.webmanifest = languages.json = {
  property: /"(?:\\.|[^\\\n"])*"(?=\s*:)/g,
  string: /"(?:\\.|[^\\\n"])*"/g,
  comment: clikeComment,
  number: /-?\b\d+(?:\.\d+)?(?:e[+-]?\d+)?\b/i,
  operator: /:/,
  punctuation: /[[\]{},]/,
  boolean,
  null: {
    pattern: /\bnull\b/,
    alias: "keyword"
  }
};
