import {
  clone,
  insertBefore
} from "./app-086jmyb9.js";
import {
  languages
} from "./app-0mckv39t.js";

// node_modules/prism-code-editor/dist/xml-shared-ONZRGEwv.js
var entity = [{
  pattern: /&[a-z\d]{1,8};/i,
  alias: "named-entity"
}, /&#x?[a-f\d]{1,8};/i];
var xmlComment = /<!--(?:(?!<!--)[^])*?-->/g;
var tag = {
  pattern: /<\/?(?!\d)[^\s/=>$<%]+(?:\s(?:\s*[^\s/=>]+(?:\s*=\s*(?!\s)(?:"[^"]*"|'[^']*'|[^\s"'=>]+(?=[\s>]))?|(?=[\s/>])))+)?\s*\/?>/g,
  inside: {
    punctuation: /^<\/?|\/?>$/,
    tag: {
      pattern: /^\S+/,
      inside: { namespace: /^[^:]+:/ }
    },
    "attr-value": [{
      pattern: /(=\s*)(?:"[^"]*"|'[^']*'|[^\s"'>]+)/g,
      lookbehind: true,
      inside: {
        punctuation: /^["']|["']$/g,
        entity
      }
    }],
    "attr-equals": /=/,
    "attr-name": {
      pattern: /\S+/,
      inside: { namespace: /^[^:]+:/ }
    }
  }
};

// node_modules/prism-code-editor/dist/prism/languages/xml.js
languages.rss = languages.atom = languages.ssml = languages.xml = {
  comment: xmlComment,
  prolog: /<\?[^]+?\?>/g,
  doctype: {
    pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/gi,
    inside: {
      "internal-subset": {
        pattern: /(\[)[^]+(?=\]\s*>$)/,
        lookbehind: true,
        inside: "xml"
      },
      string: /"[^"]*"|'[^']*'/,
      punctuation: /^<!|[>[\]]/,
      "doctype-tag": /^DOCTYPE/i,
      name: /\S+/
    }
  },
  cdata: /<!\[CDATA\[[^]*?\]\]>/gi,
  tag,
  entity,
  "markup-bracket": {
    pattern: /[()[\]{}]/,
    alias: "punctuation"
  }
};

// node_modules/prism-code-editor/dist/prism/languages/markup.js
var addLang = (grammar, lang) => {
  grammar["language-" + lang] = {
    pattern: /[^]+/,
    inside: lang
  };
  return grammar;
};
var addInlined = (tagName, lang) => ({
  pattern: RegExp(`(<${tagName}[^>]*>)(?!</${tagName}>)(?:<!\\[CDATA\\[(?:[^\\]]|\\](?!\\]>))*\\]\\]>|(?!<!\\[CDATA\\[)[^])+?(?=</${tagName}>)`, "gi"),
  lookbehind: true,
  inside: addLang({ "included-cdata": {
    pattern: /<!\[CDATA\[[^]*?\]\]>/i,
    inside: addLang({ cdata: /^<!\[CDATA\[|\]\]>$/i }, lang)
  } }, lang)
});
var addAttribute = (attrName, lang, alias = attrName) => ({
  pattern: RegExp(`([\\s"']${attrName}\\s*=\\s*)(?:"[^"]*"|'[^']*'|[^\\s>]+)`, "gi"),
  lookbehind: true,
  alias,
  inside: addLang({ punctuation: /^["']|["']$/g }, lang)
});
var markup = languages.svg = languages.mathml = languages.html = languages.markup = clone(languages.xml);
markup.tag.inside["attr-value"].unshift(addAttribute("style", "css"), addAttribute("on[a-z]+", "javascript", "script"));
insertBefore(markup, "cdata", {
  style: addInlined("style", "css"),
  script: addInlined("script", "javascript")
});
