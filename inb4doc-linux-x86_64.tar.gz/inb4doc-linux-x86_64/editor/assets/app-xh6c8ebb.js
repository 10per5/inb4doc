import{A as f}from"./app-dp5skd56.js";import{U as b}from"./app-4wb7hyrj.js";f(b.js,"jsx");
