import {
  re,
  replace
} from "./app-v8v73v6d.js";
import {
  languages
} from "./app-0mckv39t.js";
import"./app-2vd5xdaq.js";

// node_modules/prism-code-editor/dist/prism/languages/yaml.js
var anchorOrAlias = /[*&][^\s[\]{},]+/;
var tag = /!(?:<[\w%#;/?:@&=$,.!~*'()[\]+-]+>|(?:[a-zA-Z\d-]*!)?[\w%#;/?:@&=$.~*'()+-]+)?/;
var properties = `(?:${tag.source}(?:[ 	]+${anchorOrAlias.source})?|${anchorOrAlias.source}(?:[ 	]+${tag.source})?)`;
var plainKey = replace("(?:[^\\s\x00-\\x08\\x0e-\\x1f!\"#%&'*,:>?@[\\]{}`|\\x7f-\\x84\\x86-\\x9f\\ud800-\\udfff\\ufffe\\uffff-]|[?:-]<0>)(?:[ \t]*(?:(?![#:])<0>|:<0>))*", ["[^\\s\x00-\\x08\\x0e-\\x1f,[\\]{}\\x7f-\\x84\\x86-\\x9f\\ud800-\\udfff\\ufffe\\uffff]"]);
var string = `"(?:\\\\.|[^\\\\
"])*"|'(?:\\\\.|[^\\\\
'])*'`;
var createValuePattern = (value, flags) => re(`([:,[{-]\\s*(?:\\s<0>[ 	]+)?)<1>(?=[ 	]*(?:$|,|\\]|\\}|(?:
\\s*)?#))`, [properties, value], flags);
languages.yml = languages.yaml = {
  scalar: {
    pattern: re(`([:-]\\s*(?:\\s<0>[ 	]+)?[|>])[ 	]*(?:(
[ 	]+)\\S.*(?:\\2.+)*)`, [properties]),
    lookbehind: true,
    alias: "string"
  },
  comment: /#.*/,
  key: {
    pattern: re(`((?:^|[:,[{
?-])[ 	]*(?:<0>[ 	]+)?)<1>(?=\\s*:\\s)`, [properties, "(?:" + plainKey + "|" + string + ")"], "g"),
    lookbehind: true,
    alias: "atrule"
  },
  directive: {
    pattern: /(^[ 	]*)%.+/m,
    lookbehind: true,
    alias: "important"
  },
  datetime: {
    pattern: createValuePattern("\\d{4}-\\d\\d?-\\d\\d?(?:[tT]|[ \t]+)\\d\\d?:\\d\\d:\\d\\d(?:\\.\\d*)?(?:[ \t]*(?:Z|[+-]\\d\\d?(?::\\d\\d)?))?|\\d{4}-\\d\\d-\\d\\d|\\d\\d?:\\d\\d(?::\\d\\d(?:\\.\\d*)?)?", "m"),
    lookbehind: true,
    alias: "number"
  },
  boolean: {
    pattern: createValuePattern("false|true", "im"),
    lookbehind: true,
    alias: "important"
  },
  null: {
    pattern: createValuePattern("null|~", "im"),
    lookbehind: true,
    alias: "important"
  },
  string: {
    pattern: createValuePattern(string, "mg"),
    lookbehind: true
  },
  number: {
    pattern: createValuePattern("[+-]?(?:0x[a-f\\d]+|0o[0-7]+|(?:\\d+(?:\\.\\d*)?|\\.\\d+)(?:e[+-]?\\d+)?|\\.inf|\\.nan)", "im"),
    lookbehind: true
  },
  tag,
  important: anchorOrAlias,
  punctuation: /---|[:[\]{},|>?-]|\.{3}/
};
