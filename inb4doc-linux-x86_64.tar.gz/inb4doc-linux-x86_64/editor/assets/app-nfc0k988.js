import {
  re
} from "./app-v8v73v6d.js";
import {
  clone,
  insertBefore
} from "./app-086jmyb9.js";
import {
  clikeComment
} from "./app-ky8th4fh.js";
import {
  Token,
  languages,
  tokenize,
  withoutTokenizer
} from "./app-0mckv39t.js";

// node_modules/prism-code-editor/dist/jsx-shared-CZGNsLLj.js
var space = "\\s|//.*(?!.)|/\\*(?:[^*]|\\*(?!/))*\\*/";
var braces = "\\{(?:[^{}]|\\{(?:[^{}]|\\{(?:[^{}]|\\{[^}]*\\})*\\})*\\})*\\}";
var tokenizer = (code, grammar) => {
  var position = 0, tokens = withoutTokenizer(code, grammar);
  var i = 0, openedTags = [], l = 0;
  var token;
  var j = 0;
  var textStartPos;
  var content;
  var last;
  var addStoredText = () => {
    if (textStartPos) {
      content = code.slice(textStartPos, position);
      tokens[j++] = new Token("plain-text", content, content);
      textStartPos = 0;
    }
  };
  for (;token = tokens[i]; i++, position += length) {
    var length = token.length;
    var isNeverText = token.type;
    var tag, start;
    if (isNeverText) {
      content = token.content;
      if (isNeverText == "tag") {
        start = content[0].length;
        tag = content[2] ? code.substr(position + start, content[1].length) : "";
        if (start > 1) {
          if (l && last[0] == tag)
            last = openedTags[--l - 1];
        } else if (content[content.length - 1].length < 2)
          openedTags[l++] = last = [tag, 0];
      } else if (l && isNeverText == "punctuation")
        if (content == "{")
          last[1]++;
        else if (last[1] && content == "}")
          last[1]--;
        else
          isNeverText = "}()[]".includes(content);
      else
        isNeverText = false;
    }
    if (!isNeverText && l && !last[1]) {
      if (!textStartPos)
        textStartPos = position;
    } else {
      addStoredText();
      tokens[j++] = token;
    }
  }
  addStoredText();
  tokens.length = j;
  return tokens;
};
var addJsxTag = (grammar, name) => {
  insertBefore(languages[name] = grammar = clone(grammar), "regex", { tag: {
    pattern: re(`</?(?:(?!\\d)[^\\s%=<>/]+(?:<0>(?:<0>*(?:[^\\s{=<>/*]+(?:<0>*=<0>*(?!\\s)(?:"[^"]*"|'[^']*'|<1>)?|(?=[\\s/>]))|<1>))*)?<0>*/?)?>`, [space, braces], "g"),
    inside: {
      punctuation: /^<\/?|\/?>$/,
      tag: {
        pattern: /^[^\s/<]+/,
        inside: {
          namespace: /^[^:]+:/,
          "class-name": /^[A-Z]\w*(?:\.[A-Z]\w*)*$/
        }
      },
      "attr-value": {
        pattern: re(`(=<0>*)(?:"[^"]*"|'[^']*')`, [space]),
        lookbehind: true,
        inside: { punctuation: /^["']|["']$/g }
      },
      expression: {
        pattern: RegExp(braces, "g"),
        alias: "language-" + name,
        inside: grammar
      },
      comment: clikeComment,
      "attr-equals": /=/,
      "attr-name": {
        pattern: /\S+/,
        inside: { namespace: /^[^:]+:/ }
      }
    }
  } });
  grammar[tokenize] = tokenizer;
  return grammar;
};

export { space, braces, addJsxTag };
