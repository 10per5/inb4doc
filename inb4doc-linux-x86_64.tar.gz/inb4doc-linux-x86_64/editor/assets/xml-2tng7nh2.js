import {
  markupLanguage
} from "./app-98xjztvq.js";
import {
  languageMap
} from "./app-9metdmjj.js";
import"./app-xjz2c8ce.js";
import"./app-v8v73v6d.js";
import"./app-ky8th4fh.js";
import"./app-bdyxzr9h.js";
import"./app-db5x50nb.js";

// node_modules/prism-code-editor/dist/languages/xml.js
languageMap.xml = languageMap.ssml = languageMap.atom = languageMap.rss = languageMap.mathml = languageMap.svg = markupLanguage();
