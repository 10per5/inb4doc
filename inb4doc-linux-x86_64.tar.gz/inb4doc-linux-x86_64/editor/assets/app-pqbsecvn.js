import {
  escapeHtml,
  highlightTokens,
  languages,
  tokenizeText
} from "./app-0mckv39t.js";

// node_modules/prism-code-editor/dist/core-fngiDtt5.js
var createEditor = (container, options, ...extensions) => {
  let language;
  let prevLines = [];
  let activeLine;
  let value = "";
  let activeLineNumber;
  let focused = false;
  let handleSelectionChange = true;
  let tokens = [];
  let readOnly;
  let lineCount = 0;
  const scrollContainer = editorTemplate();
  const wrapper = scrollContainer.firstChild;
  const lines = wrapper.children;
  const overlays = lines[0];
  const textarea = overlays.firstChild;
  const currentOptions = {
    language: "text",
    value
  };
  const currentExtensions = new Set(extensions);
  const listeners = {};
  const setOptions = (options2) => {
    Object.assign(currentOptions, options2);
    let isNewVal = value != (value = options2.value ?? value);
    let isNewLang = language != (language = currentOptions.language);
    readOnly = !!currentOptions.readOnly;
    scrollContainer.style.tabSize = currentOptions.tabSize || 2;
    textarea.inputMode = readOnly ? "none" : "";
    textarea.setAttribute("aria-readonly", readOnly);
    updateClassName();
    updateExtensions();
    if (isNewVal) {
      if (!focused)
        textarea.remove();
      textarea.value = value;
      textarea.selectionEnd = 0;
      if (!focused)
        overlays.prepend(textarea);
    }
    if (isNewVal || isNewLang)
      update();
  };
  const update = () => {
    tokens = tokenizeText(value = textarea.value, languages[language] || {});
    dispatchEvent("tokenize", tokens, language, value);
    let newLines = highlightTokens(tokens).split(`
`);
    let start = 0;
    let end2 = lineCount;
    let end1 = lineCount = newLines.length;
    while (newLines[start] == prevLines[start] && start < end1)
      ++start;
    while (end1 && newLines[--end1] == prevLines[--end2])
      ;
    if (start == end1 && start == end2)
      lines[start + 1].innerHTML = newLines[start] + `
`;
    else {
      let insertStart = end2 < start ? end2 : start - 1;
      let i = insertStart;
      let newHTML = "";
      while (i < end1)
        newHTML += `<div class=pce-line aria-hidden=true>${newLines[++i]}
</div>`;
      for (i = end1 < start ? end1 : start - 1;i < end2; i++)
        lines[start + 1].remove();
      if (newHTML)
        lines[insertStart + 1].insertAdjacentHTML("afterend", newHTML);
      scrollContainer.style.setProperty("--number-width", (0 | Math.log10(lineCount)) + 1 + ".001ch");
    }
    dispatchEvent("update", value);
    dispatchSelection(true);
    if (handleSelectionChange)
      setTimeout(setTimeout, 0, () => handleSelectionChange = true);
    prevLines = newLines;
    handleSelectionChange = false;
  };
  const updateExtensions = (newExtensions) => {
    (newExtensions || currentExtensions).forEach((extension) => {
      if (typeof extension == "object") {
        extension.update(self, currentOptions);
        if (newExtensions)
          currentExtensions.add(extension);
      } else {
        extension(self, currentOptions);
        if (!newExtensions)
          currentExtensions.delete(extension);
      }
    });
  };
  const updateClassName = ([start, end] = getInputSelection()) => {
    scrollContainer.className = `prism-code-editor language-${language}${currentOptions.lineNumbers == false ? "" : " show-line-numbers"} pce-${currentOptions.wordWrap ? "" : "no"}wrap${currentOptions.rtl ? " pce-rtl" : ""} pce-${start < end ? "has" : "no"}-selection${focused ? " pce-focus" : ""}${readOnly ? " pce-readonly" : ""}${currentOptions.class ? " " + currentOptions.class : ""}`;
  };
  const getInputSelection = () => [
    textarea.selectionStart,
    textarea.selectionEnd,
    textarea.selectionDirection
  ];
  const keyCommandMap = { Escape() {
    textarea.blur();
  } };
  const inputCommandMap = {};
  const dispatchEvent = (name, ...args) => {
    listeners[name]?.forEach((handler) => handler.apply(self, args));
    currentOptions["on" + name[0].toUpperCase() + name.slice(1)]?.(...args, self);
  };
  const dispatchSelection = (force) => {
    if (force || handleSelectionChange) {
      const selection = getInputSelection();
      const newLine = lines[activeLineNumber = numLines(value, 0, selection[selection[2] < "f" ? 0 : 1])];
      if (newLine != activeLine) {
        activeLine?.classList.remove("active-line");
        newLine.classList.add("active-line");
        activeLine = newLine;
      }
      updateClassName(selection);
      dispatchEvent("selectionChange", selection, value);
    }
  };
  const self = {
    container: scrollContainer,
    wrapper,
    lines,
    textarea,
    get activeLine() {
      return activeLineNumber;
    },
    get value() {
      return value;
    },
    options: currentOptions,
    get focused() {
      return focused;
    },
    get tokens() {
      return tokens;
    },
    inputCommandMap,
    keyCommandMap,
    extensions: {},
    setOptions,
    update,
    getSelection: getInputSelection,
    addExtensions(...extensions2) {
      updateExtensions(extensions2);
    },
    on: (name, handler) => {
      (listeners[name] ||= /* @__PURE__ */ new Set).add(handler);
      return () => listeners[name].delete(handler);
    },
    remove() {
      scrollContainer.remove();
    }
  };
  addListener(textarea, "keydown", (e) => {
    keyCommandMap[e.key]?.(e, getInputSelection(), value) && preventDefault(e);
  });
  addListener(textarea, "beforeinput", (e) => {
    if (readOnly || e.inputType == "insertText" && inputCommandMap[e.data]?.(e, getInputSelection(), value))
      preventDefault(e);
  });
  addListener(textarea, "input", update);
  addListener(textarea, "blur", () => {
    selectionChange = null;
    focused = false;
    updateClassName();
  });
  addListener(textarea, "focus", () => {
    selectionChange = dispatchSelection;
    focused = true;
    updateClassName();
  });
  addListener(textarea, "selectionchange", (e) => {
    dispatchSelection(!e.isTrusted);
    preventDefault(e);
  });
  getElement(container)?.append(scrollContainer);
  options && setOptions(options);
  return self;
};
var doc = "u" > typeof window ? document : null;
var templateEl = /* @__PURE__ */ doc?.createElement("div");
var createTemplate = (html, node) => {
  if (templateEl) {
    templateEl.innerHTML = html;
    node = templateEl.firstChild;
  }
  return () => node.cloneNode(true);
};
var addListener = (target, type, listener, options) => target.addEventListener(type, listener, options);
var getElement = (el) => typeof el == "string" ? doc.querySelector(el) : el;
var numLines = (str, start = 0, end = Infinity) => {
  let count = 1;
  for (;(start = str.indexOf(`
`, start) + 1) && start <= end; count++)
    ;
  return count;
};
var languageMap = {};
var editorTemplate = /* @__PURE__ */ createTemplate("<div><div class=pce-wrapper><div class=pce-overlays><textarea class=pce-textarea spellcheck=false autocapitalize=off autocomplete=off>");
var preventDefault = (e) => {
  e.preventDefault();
  e.stopImmediatePropagation();
};
var selectionChange;
if (doc)
  addListener(doc, "selectionchange", () => selectionChange?.());

// node_modules/prism-code-editor/dist/utils-umP5W0OV.js
var getLineStart = (text, position) => position ? text.lastIndexOf(`
`, position - 1) + 1 : 0;
var getLineEnd = (text, position) => (position = text.indexOf(`
`, position)) + 1 ? position : text.length;
var addListener2 = (element, type, listener, options) => {
  addListener(element, type, listener, options);
  return () => element.removeEventListener(type, listener, options);
};
var addTextareaListener = (editor, type, listener, options) => addListener2(editor.textarea, type, listener, options);
var getStyleValue = (el, prop) => parseFloat(getComputedStyle(el)[prop]);
var voidlessLangs = new Set("xml,rss,atom,jsx,tsx,xquery,xeora,xeoracube,actionscript".split(","));
var voidTags = /^(?:area|base|w?br|col|embed|hr|img|input|link|meta|source|track)$/;
var prevSelection;
var regexEscape = (str) => str.replace(/[$+?|.^*()[\]{}\\]/g, "\\$&");
var getLineBefore = (text, position) => text.slice(getLineStart(text, position), position);
var getLines = (text, start, end = start) => [
  text.slice(start = getLineStart(text, start), end = getLineEnd(text, end)).split(`
`),
  start,
  end
];
var getClosestToken = (editor, selector, marginLeft = 0, marginRight = marginLeft, position = editor.getSelection()[0]) => {
  const value = editor.value;
  const line = editor.lines[numLines(value, 0, position)];
  const walker = doc.createTreeWalker(line, 5);
  let node = walker.lastChild();
  let offset = getLineEnd(value, position) + 1 - position - node.length;
  while (-offset <= marginRight && (node = walker.previousNode())) {
    if (node.lastChild)
      continue;
    offset -= node.length || 0;
    if (offset <= marginLeft) {
      for (;node != line; node = node.parentNode)
        if (node.matches?.(selector))
          return node;
    }
  }
};
var getLanguage = (editor, position) => getClosestToken(editor, "[class*=language-]", 0, 0, position)?.className.match(/language-(\S*)/)[1] || editor.options.language;
var insertText = (editor, text, start, end, newCursorStart, newCursorEnd) => {
  if (editor.options.readOnly)
    return;
  prevSelection = editor.getSelection();
  end ??= start;
  let textarea = editor.textarea;
  let value = editor.value;
  let avoidBug = isChrome && !value[end ?? prevSelection[1]] && /\n$/.test(text) && /^$|\n$/.test(value);
  let removeListener;
  editor.focused || textarea.focus();
  if (start != null)
    textarea.setSelectionRange(start, end);
  if (newCursorStart != null)
    removeListener = editor.on("update", () => {
      textarea.setSelectionRange(newCursorStart, newCursorEnd ?? newCursorStart, prevSelection[2]);
      removeListener();
    });
  isWebKit || textarea.dispatchEvent(new InputEvent("beforeinput", { data: text }));
  if (isChrome || isWebKit) {
    if (avoidBug) {
      textarea.selectionEnd--;
      text = text.slice(0, -1);
    }
    if (isWebKit)
      text += `
`;
    doc.execCommand(text ? "insertHTML" : "delete", false, escapeHtml(text, /</g, "&lt;"));
    if (avoidBug)
      textarea.selectionStart++;
  } else
    doc.execCommand(text ? "insertText" : "delete", false, text);
  prevSelection = 0;
};
var setSelection = (editor, start, end = start, direction) => {
  let textarea = editor.textarea;
  let removeHandler = addListener2(textarea, "focus", (e) => {
    let target = e.relatedTarget;
    target ? target.focus() : textarea.blur();
  });
  textarea.setSelectionRange(start, end, direction);
  removeHandler();
  textarea.dispatchEvent(new Event("selectionchange"));
};
var userAgent = doc ? navigator.userAgent : "";
var isMac = doc ? /Mac|iPhone|iP[ao]d/.test(navigator.platform) : false;
var isChrome = /Chrome\//.test(userAgent);
var isWebKit = !isChrome && /AppleWebKit\//.test(userAgent);
var getModifierCode = (e) => e.altKey + e.ctrlKey * 2 + e.metaKey * 4 + e.shiftKey * 8;

export { createEditor, languageMap, preventDefault, getLineStart, getLineEnd, addTextareaListener, getStyleValue, voidTags, regexEscape, getLineBefore, getLines, getClosestToken, getLanguage, insertText, setSelection, isMac, getModifierCode };
