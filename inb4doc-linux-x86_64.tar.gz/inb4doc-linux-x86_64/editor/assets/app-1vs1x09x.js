import {
  addJsxTag
} from "./app-xjz2c8ce.js";
import {
  languages
} from "./app-db5x50nb.js";

// node_modules/prism-code-editor/dist/prism/languages/jsx.js
addJsxTag(languages.js, "jsx");
