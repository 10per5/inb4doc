import {
  markupComment,
  markupLanguage,
  xmlOpeningTag
} from "./app-26vfkf71.js";
import {
  languageMap,
  voidTags
} from "./app-pqbsecvn.js";
import"./app-w2q81w53.js";
import"./app-v8v73v6d.js";
import"./app-ky8th4fh.js";
import"./app-086jmyb9.js";
import"./app-0mckv39t.js";
import"./app-2vd5xdaq.js";

// node_modules/prism-code-editor/dist/languages/html.js
languageMap.markup = languageMap.html = languageMap.markdown = languageMap.md = markupLanguage(markupComment, xmlOpeningTag, voidTags);
