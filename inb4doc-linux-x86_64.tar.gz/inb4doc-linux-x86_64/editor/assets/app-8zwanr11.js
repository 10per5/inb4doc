import {
  addJsxTag
} from "./app-gccwp0hh.js";
import {
  languages
} from "./app-db5x50nb.js";

// node_modules/prism-code-editor/dist/prism/languages/jsx.js
addJsxTag(languages.js, "jsx");
