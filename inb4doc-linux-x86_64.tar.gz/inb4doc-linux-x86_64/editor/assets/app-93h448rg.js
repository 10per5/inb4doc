import {
  addJsxTag
} from "./app-w2q81w53.js";
import {
  languages
} from "./app-0mckv39t.js";

// node_modules/prism-code-editor/dist/prism/languages/jsx.js
addJsxTag(languages.js, "jsx");
