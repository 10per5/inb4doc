import"./app-y07eqd9r.js";
import"./app-93h448rg.js";
import"./app-xqky8wym.js";
import {
  addJsxTag,
  space
} from "./app-w2q81w53.js";
import {
  re
} from "./app-v8v73v6d.js";
import"./app-ky8th4fh.js";
import {
  insertBefore
} from "./app-086jmyb9.js";
import {
  languages
} from "./app-0mckv39t.js";
import"./app-2vd5xdaq.js";

// node_modules/prism-code-editor/dist/prism/languages/tsx.js
var tsx = addJsxTag(languages.ts, "tsx");
var tag = tsx["tag"];
var bracket = "(?:^|(";
try {
  bracket += "?<=";
} catch {
  tag.lookbehind = true;
}
tag.pattern = RegExp(bracket + `[^\\w$])|(?=</))${tag.pattern.source.replace(space, space + `|(?:${space})*<(?:[^<>=]|=[^<]|=?<(?:[^<>]|<[^<>]*>)*>)*>`)}`, "g");
insertBefore(tag.inside, "attr-value", { generic: {
  pattern: re("(^<0>*)<(?:[^<>=]|=[^<]|=?<(?:[^<>]|<[^<>]*>)*>)*>", [space]),
  lookbehind: true,
  alias: "class-name",
  inside: tsx["class-name"].inside
} });
