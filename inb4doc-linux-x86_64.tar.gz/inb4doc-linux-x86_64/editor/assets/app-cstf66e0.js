import{A as f}from"./app-n0atxmek.js";import{U as b}from"./app-4wb7hyrj.js";f(b.js,"jsx");
