var u=4000,y={danger:"#e03e3e",warning:"#d08731",info:"#388bf2",success:"#2ea043"},x={danger:"✕",warning:"⚠",info:"ℹ",success:"✓"},n=null;function b(){if(!n){if(n=document.getElementById("prdc-notifications"),!n)n=document.createElement("div"),n.id="prdc-notifications",document.body.appendChild(n)}return n}function h(i,a){let f=a?.duration??u,p=a?.type??"danger",m=a?.title,c=a?.id,g=b();if(c){let e=g.querySelector(`[data-nid="${c}"]`);if(e)e.remove()}let t=document.createElement("div");if(t.className="prdc-notification",t.style.background=y[p],c)t.dataset.nid=c;let o=document.createElement("button");o.className="prdc-notif-close",o.textContent="✕",o.addEventListener("click",(e)=>{e.stopPropagation(),t.remove()}),t.appendChild(o);let s=document.createElement("span");s.className="prdc-notif-icon",s.textContent=x[p],t.appendChild(s);let d=document.createElement("div");if(d.className="prdc-notif-body",m){let e=document.createElement("div");e.className="prdc-notif-title",e.textContent=m,d.appendChild(e)}let l=document.createElement("div");if(l.className="prdc-notif-msg",l.textContent=i,d.appendChild(l),t.appendChild(d),g.appendChild(t),f>0){let e=t.animate([{opacity:1,transform:"translateY(0)"},{opacity:0,transform:"translateY(-8px)"}],{duration:300,fill:"forwards",delay:f-300,easing:"ease-out"});e.onfinish=()=>{if(t.isConnected)t.remove()},o.addEventListener("click",()=>e.cancel())}}function E(){if(document.getElementById("prdc-notification-styles"))return;let i=document.createElement("style");i.id="prdc-notification-styles",i.textContent=`
#prdc-notifications {
  position: fixed; bottom: 1rem; right: 1rem; z-index: 100000;
  display: flex; flex-direction: column; gap: 0.5rem;
  pointer-events: none;
  max-width: min(90vw, 400px);
}
.prdc-notification {
  pointer-events: auto;
  position: relative;
  display: flex; align-items: flex-start; gap: 0.625rem;
  color: #fff; padding: 0.625rem 0.875rem;
  border-radius: 10px;
  font: 13px/1.45 system-ui, sans-serif;
  box-shadow: 0 4px 16px rgba(0,0,0,.45);
  animation: prdc-notif-in .2s ease-out;
  min-width: 240px;
}
.prdc-notif-close {
  position: absolute; top: 4px; right: 4px;
  width: 1.25rem; height: 1.25rem; padding: 0; border: none; cursor: pointer;
  display: none; align-items: center; justify-content: center;
  font-size: 10px; line-height: 1;
  border-radius: 50%; background: rgba(0,0,0,.25); color: #fff;
}
.prdc-notification:hover .prdc-notif-close { display: flex; }
.prdc-notif-icon {
  flex-shrink: 0; width: 1.25rem; height: 1.25rem;
  display: flex; align-items: center; justify-content: center;
  font-size: 13px; font-weight: 700;
  border-radius: 50%;
  background: rgba(0,0,0,.2);
  margin-top: 1px;
}
.prdc-notif-body {
  flex: 1; min-width: 0;
}
.prdc-notif-title {
  font-weight: 600; margin-bottom: 0.125rem;
}
.prdc-notif-msg {
  opacity: .88;
}
@keyframes prdc-notif-in {
  from { opacity: 0; transform: translateX(100%); }
  to   { opacity: 1; transform: translateX(0); }
}
  `,document.head.appendChild(i)}var r={dark:"#2e3440",mutedText:"#4c566a",lightBorder:"#d8dee9",lightBg:"#e5e9f0",lighterBg:"#eceff4",teal:"#8fbcbb",primary:"#5e81ac",danger:"#bf616a",orange:"#d08770",yellow:"#ebcb8b",green:"#a3be8c"},w={success:{idle:{bg:r.primary,color:"#fff"},pending:{bg:"#4a7098",color:"#fff"}},danger:{idle:{bg:r.danger,color:"#fff"},pending:{bg:"#e65100",color:"#fff"}},warning:{idle:{bg:r.yellow,color:r.dark},pending:{bg:r.orange,color:"#fff"}}};
export{r as s,w as t,h as u,E as v};
